using System.Text.Json;
using ASelyPhotoBooth.Models;
using Microsoft.JSInterop;

namespace ASelyPhotoBooth.Services;

/// <summary>
/// Typed wrapper over the browser-side modules in wwwroot/js.
/// Camera logic (asely-camera.js) is kept apart from editor logic (asely-editor.js, asely-reel.js).
/// </summary>
public sealed class BoothInterop
{
    private readonly IJSRuntime _js;
    public static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);

    public BoothInterop(IJSRuntime js) => _js = js;

    // ---------- camera ----------
    public ValueTask<bool> CameraSupported() => _js.InvokeAsync<bool>("AselyCamera.supported");
    public ValueTask<bool> SecureContext() => _js.InvokeAsync<bool>("AselyCamera.secureContext");
    public ValueTask<bool> RecorderSupported() => _js.InvokeAsync<bool>("AselyCamera.recorderSupported");
    public ValueTask<bool> CanPause() => _js.InvokeAsync<bool>("AselyCamera.canPause");
    public ValueTask<CameraStartResult> StartCamera(string videoId, string facing) =>
        _js.InvokeAsync<CameraStartResult>("AselyCamera.start", videoId, facing);
    public ValueTask<bool> StopCamera() => _js.InvokeAsync<bool>("AselyCamera.stop");
    public ValueTask<bool> CameraIsOn() => _js.InvokeAsync<bool>("AselyCamera.isOn");
    public ValueTask<SimpleResult> EnableMic() => _js.InvokeAsync<SimpleResult>("AselyCamera.enableMic");
    public ValueTask<bool> DisableMic() => _js.InvokeAsync<bool>("AselyCamera.disableMic");
    public ValueTask<MediaItem> Capture(string sessionId, bool mirror, string? replaceId = null) =>
        _js.InvokeAsync<MediaItem>("AselyCamera.capture", sessionId, mirror, replaceId);
    public ValueTask<RecordStartResult> StartRecording(bool withAudio) =>
        _js.InvokeAsync<RecordStartResult>("AselyCamera.startRecording", withAudio);
    public ValueTask<bool> PauseRecording() => _js.InvokeAsync<bool>("AselyCamera.pause");
    public ValueTask<bool> ResumeRecording() => _js.InvokeAsync<bool>("AselyCamera.resume");
    public ValueTask<double> Elapsed() => _js.InvokeAsync<double>("AselyCamera.elapsed");
    public ValueTask<string?> RecordingFailed() => _js.InvokeAsync<string?>("AselyCamera.recordingFailed");
    public ValueTask<MediaItem?> StopRecording(string sessionId, string origin) =>
        _js.InvokeAsync<MediaItem?>("AselyCamera.stopRecording", sessionId, origin, null);
    public ValueTask<bool> DiscardRecording() => _js.InvokeAsync<bool>("AselyCamera.discardRecording");

    // ---------- store ----------
    public async Task<List<MediaItem>> List() =>
        (await _js.InvokeAsync<MediaItem[]>("AselyStore.list")).ToList();
    public ValueTask<string> ObjectUrl(string id) => _js.InvokeAsync<string>("AselyStore.objectUrl", id);
    public ValueTask<bool> Remove(string id) => _js.InvokeAsync<bool>("AselyStore.remove", id);
    public ValueTask<bool> RemoveMany(IEnumerable<string> ids) => _js.InvokeAsync<bool>("AselyStore.removeMany", ids.ToArray());
    public ValueTask<bool> ClearAll() => _js.InvokeAsync<bool>("AselyStore.clearAll");
    public ValueTask<bool> Persist(string id) => _js.InvokeAsync<bool>("AselyStore.persist", id);
    public ValueTask<bool> Unpersist(string id) => _js.InvokeAsync<bool>("AselyStore.unpersist", id);
    public ValueTask<bool> GetAutoSave() => _js.InvokeAsync<bool>("AselyStore.getAutoSave");
    public ValueTask<bool> SetAutoSave(bool on) => _js.InvokeAsync<bool>("AselyStore.setAutoSave", on);
    public ValueTask<StorageEstimate> Estimate() => _js.InvokeAsync<StorageEstimate>("AselyStore.estimate");
    public async Task<List<MediaItem>> ImportFiles(string inputId, string sessionId, string group) =>
        (await _js.InvokeAsync<MediaItem[]>("AselyStore.importFiles", inputId, sessionId, group)).ToList();

    // ---------- downloads and sharing ----------
    public ValueTask<bool> Download(string id, string filename) => _js.InvokeAsync<bool>("AselyUtil.downloadById", id, filename);
    public ValueTask<bool> CanShareFiles() => _js.InvokeAsync<bool>("AselyUtil.canShareFiles");
    public ValueTask<string> Share(string id, string filename, string title) =>
        _js.InvokeAsync<string>("AselyUtil.shareById", id, filename, title);
    public ValueTask<int> DownloadZip(IEnumerable<string> ids, string zipName) =>
        _js.InvokeAsync<int>("AselyUtil.downloadZip", ids.ToArray(), zipName);
    public ValueTask<string> Stamp(string? iso, string style) => _js.InvokeAsync<string>("AselyUtil.stamp", iso, style);
    public ValueTask<string> Permission(string name) => _js.InvokeAsync<string>("AselyUtil.permission", name);

    // ---------- photo editor ----------
    public ValueTask<bool> EditorInit<T>(string canvasId, DotNetObjectReference<T> self) where T : class =>
        _js.InvokeAsync<bool>("AselyEditor.init", canvasId, self);
    public ValueTask<bool> EditorRender(PhotoComposition c, string? selected) =>
        _js.InvokeAsync<bool>("AselyEditor.render", JsonSerializer.Serialize(c, Json), selected);
    public ValueTask<bool> EditorSelect(string? id) => _js.InvokeAsync<bool>("AselyEditor.setSelected", id);
    public ValueTask<MediaItem> EditorSave(string sessionId, string name) => _js.InvokeAsync<MediaItem>("AselyEditor.save", sessionId, name);
    public ValueTask<bool> EditorDownload(string filename) => _js.InvokeAsync<bool>("AselyEditor.download", filename);
    public ValueTask<string> EditorShare(string filename) => _js.InvokeAsync<string>("AselyEditor.share", filename);
    public ValueTask<bool> EditorDispose() => _js.InvokeAsync<bool>("AselyEditor.dispose");
    public ValueTask<bool> PaintThumbs() => _js.InvokeAsync<bool>("AselyArt.paintThumbs");

    // ---------- memory reel editor ----------
    public ValueTask<bool> ReelInit<T>(string canvasId, string videoId, DotNetObjectReference<T> self) where T : class =>
        _js.InvokeAsync<bool>("AselyReel.init", canvasId, videoId, self);
    public ValueTask<ReelInfo> ReelLoad(string id) => _js.InvokeAsync<ReelInfo>("AselyReel.load", id);
    public ValueTask<bool> ReelConfig(ReelComposition c, string? selected) =>
        _js.InvokeAsync<bool>("AselyReel.setConfig", JsonSerializer.Serialize(c, Json), selected);
    public ValueTask<bool> ReelSelect(string? id) => _js.InvokeAsync<bool>("AselyReel.setSelected", id);
    public ValueTask<bool> ReelPlay() => _js.InvokeAsync<bool>("AselyReel.play");
    public ValueTask<bool> ReelPause() => _js.InvokeAsync<bool>("AselyReel.pause");
    public ValueTask<bool> ReelSeek(double t) => _js.InvokeAsync<bool>("AselyReel.seek", t);
    public ValueTask<bool> ReelCancelExport() => _js.InvokeAsync<bool>("AselyReel.cancelExport");
    public ValueTask<MediaItem> ReelExport<T>(ReelComposition c, string sessionId, DotNetObjectReference<T> progress) where T : class =>
        _js.InvokeAsync<MediaItem>("AselyReel.exportReel", JsonSerializer.Serialize(c, Json), sessionId, progress);
    public ValueTask<bool> ReelDispose() => _js.InvokeAsync<bool>("AselyReel.dispose");

    public static List<DecoItem> ParseItems(string json)
    {
        try { return JsonSerializer.Deserialize<List<DecoItem>>(json, Json) ?? new(); }
        catch (JsonException) { return new(); }
    }
}
