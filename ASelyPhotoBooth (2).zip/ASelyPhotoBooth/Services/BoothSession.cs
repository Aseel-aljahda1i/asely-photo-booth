using ASelyPhotoBooth.Models;

namespace ASelyPhotoBooth.Services;

/// <summary>
/// Remembers what is going on between pages (Studio -> Editor -> Reel -> Gallery).
/// Only ids and settings live here, never image bytes, and it is gone when the tab closes.
/// </summary>
public sealed class BoothSession
{
    public static readonly IReadOnlyList<LayoutOption> Layouts = new[]
    {
        new LayoutOption("single", "Single photo", 1, "One big polaroid-style photo"),
        new LayoutOption("strip2", "2-photo strip", 2, "Tall strip with two photos"),
        new LayoutOption("strip3", "3-photo strip", 3, "The classic booth strip"),
        new LayoutOption("strip4", "4-photo strip", 4, "Long vertical strip"),
        new LayoutOption("grid4", "4-photo grid", 4, "Square 2 x 2 postcard"),
    };

    public string SessionId { get; private set; } = NewId();
    public string Layout { get; set; } = "strip3";
    /// <summary>Photos chosen for the strip, in order.</summary>
    public List<string> PhotoIds { get; set; } = new();
    public string? ReelVideoId { get; set; }

    public static string NewId() => Guid.NewGuid().ToString("N")[..10];

    public static int SlotCount(string layout) => Layouts.FirstOrDefault(l => l.Id == layout)?.Slots ?? 1;

    public void StartNewSession()
    {
        SessionId = NewId();
        PhotoIds = new();
        ReelVideoId = null;
    }
}

/// <summary>Plain-language messages for things that can go wrong.</summary>
public static class Friendly
{
    public static string Camera(string? code) => code switch
    {
        "denied" => "Camera access was blocked. Tap the camera icon in your browser's address bar, allow the camera for this site, then press Start Camera again.",
        "notfound" => "No camera was found. Plug one in (or check that another app isn't hiding it) and try again.",
        "inuse" => "The camera is busy. Close other apps or tabs that are using it, then try again.",
        "unsupported" => "This browser can't open the camera here. The camera needs a secure (https) page and a recent browser such as Chrome, Edge, Safari or Firefox.",
        "recording" => "Stop the recording before switching the camera.",
        "constraint" => "That camera isn't available. Try the other one.",
        _ => "The camera couldn't start. Please check your browser's camera permission and try again."
    };

    public static string Mic(string? code) => code switch
    {
        "denied" => "Microphone access was blocked, so the recording will be silent. You can allow it in your browser's site settings and switch sound on again.",
        "notfound" => "No microphone was found, so the recording will be silent.",
        "inuse" => "The microphone is busy in another app, so the recording will be silent.",
        _ => "The microphone isn't available, so the recording will be silent."
    };

    public static string Storage(string message) => message switch
    {
        "storage_full" => "Your browser's storage is full, so this couldn't be kept on the device. It's still here until you close the tab. Download it, or delete older memories to make room.",
        "idb_unavailable" => "This browser isn't allowing local storage right now (private windows often don't). The memory stays here until you close the tab, so download it to keep it.",
        _ => "That couldn't be saved on this device."
    };

    public static string Export(string message) => message switch
    {
        "unsupported" => "This browser can't render videos. Try a recent Chrome, Edge or Firefox for the Memory Reel editor.",
        "cancelled" => "Export cancelled.",
        "not_found" => "The original video isn't available any more.",
        _ => "The video export didn't finish. Keep this tab in front while exporting, and try again."
    };

    public static string Import(string message) => message switch
    {
        "invalid_type" => "That file type isn't supported. Photos: JPG, PNG or WebP. Videos: MP4, WebM or MOV.",
        "too_large" => "That file is too big. Photos can be up to 20 MB and videos up to 700 MB.",
        _ => "That file couldn't be imported."
    };

    /// <summary>Strips the JS "Error: " prefix that comes back through interop.</summary>
    public static string Code(Exception e)
    {
        var m = e.Message ?? "";
        foreach (var k in new[] { "storage_full", "idb_unavailable", "invalid_type", "too_large", "unsupported", "cancelled", "not_found", "camera_off", "nothing_to_zip", "zip_too_large", "record_failed", "export_failed", "busy" })
            if (m.Contains(k, StringComparison.Ordinal)) return k;
        return "unknown";
    }

    public static string Size(long bytes) =>
        bytes >= 1_048_576 ? $"{bytes / 1_048_576.0:0.#} MB" : bytes >= 1024 ? $"{bytes / 1024.0:0} KB" : $"{bytes} B";

    public static string Clock(double seconds)
    {
        if (double.IsNaN(seconds) || double.IsInfinity(seconds) || seconds < 0) seconds = 0;
        var t = TimeSpan.FromSeconds(seconds);
        return $"{(int)t.TotalMinutes:00}:{t.Seconds:00}";
    }
}
