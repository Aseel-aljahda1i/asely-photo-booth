namespace ASelyPhotoBooth.Models;

/// <summary>Metadata of one stored photo, strip, video or reel. The bytes stay in the browser.</summary>
public sealed class MediaItem
{
    public string Id { get; set; } = "";
    public string SessionId { get; set; } = "none";
    /// <summary>photo | strip | video | reel</summary>
    public string Kind { get; set; } = "photo";
    /// <summary>camera | import | editor | clip | session</summary>
    public string Origin { get; set; } = "";
    public string Mime { get; set; } = "";
    public long Size { get; set; }
    public string Created { get; set; } = "";
    public string Name { get; set; } = "";
    public double Duration { get; set; }
    public bool Persisted { get; set; }
    public bool PersistFailed { get; set; }
    public bool Fallback { get; set; }

    public DateTimeOffset CreatedAt =>
        DateTimeOffset.TryParse(Created, out var d) ? d.ToLocalTime() : DateTimeOffset.Now;

    public bool IsVideo => Kind is "video" or "reel";

    public string Extension => Mime.ToLowerInvariant() switch
    {
        var m when m.Contains("mp4") => "mp4",
        var m when m.Contains("webm") => "webm",
        var m when m.Contains("quicktime") => "mov",
        var m when m.Contains("png") => "png",
        var m when m.Contains("webp") => "webp",
        var m when m.Contains("jpeg") || m.Contains("jpg") => "jpg",
        _ => "bin"
    };

    public string FileName
    {
        get
        {
            var baseName = string.IsNullOrWhiteSpace(Name) ? $"asely-{Kind}-{CreatedAt:yyyyMMdd-HHmmss}" : Name.Trim();
            foreach (var c in Path.GetInvalidFileNameChars()) baseName = baseName.Replace(c, '_');
            var dot = baseName.LastIndexOf('.');
            if (dot > 0 && baseName.Length - dot <= 5) baseName = baseName[..dot];
            return $"{baseName}.{Extension}";
        }
    }

    public string KindLabel => Kind switch
    {
        "photo" => "Photo",
        "strip" => "Photo strip",
        "video" => Origin == "session" ? "Original session video" : "Video",
        "reel" => "Edited Memory Reel",
        _ => Kind
    };
}

/// <summary>A sticker, text label or date stamp placed on a photo or video.</summary>
public sealed class DecoItem
{
    public string Id { get; set; } = "";
    /// <summary>sticker | text | date</summary>
    public string Type { get; set; } = "sticker";
    public string Sprite { get; set; } = "heart";
    public string Text { get; set; } = "";
    public string Font { get; set; } = "rounded";
    public string Color { get; set; } = "#554653";
    public double Size { get; set; } = 0.18;
    public double X { get; set; } = 0.5;
    public double Y { get; set; } = 0.5;
    public double Rot { get; set; }

    public bool IsText => Type is "text" or "date";
}

/// <summary>Everything the canvas needs to draw a photo or strip.</summary>
public sealed class PhotoComposition
{
    public string Layout { get; set; } = "single";
    public List<string?> Slots { get; set; } = new();
    public string Frame { get; set; } = "polaroid";
    public string Background { get; set; } = "solid:#F9DDE5";
    public string Filter { get; set; } = "none";
    public int Brightness { get; set; } = 100;
    public int Contrast { get; set; } = 100;
    public int Saturation { get; set; } = 100;
    public int Beauty { get; set; } = 40;
    public string Caption { get; set; } = "";
    public bool ShowDate { get; set; } = true;
    public string DateText { get; set; } = "";
    public List<DecoItem> Items { get; set; } = new();
}

/// <summary>Everything the canvas needs to draw the Memory Reel overlays.</summary>
public sealed class ReelComposition
{
    public string Frame { get; set; } = "camcorder";
    public string Look { get; set; } = "none";
    public int Grain { get; set; } = 15;
    public bool DateStamp { get; set; } = true;
    public string DateText { get; set; } = "";
    public bool ShowRec { get; set; } = true;
    public bool Mirror { get; set; }
    public List<DecoItem> Items { get; set; } = new();
}

public sealed class CameraStartResult
{
    public bool Ok { get; set; }
    public string? Error { get; set; }
    public string? Message { get; set; }
    public int Cameras { get; set; }
    public string? Facing { get; set; }
    public int Width { get; set; }
    public int Height { get; set; }
}

public sealed class SimpleResult
{
    public bool Ok { get; set; }
    public string? Error { get; set; }
}

public sealed class RecordStartResult
{
    public bool Ok { get; set; }
    public string? Error { get; set; }
    public string? Mime { get; set; }
    public bool Audio { get; set; }
}

public sealed class ReelInfo
{
    public double Duration { get; set; }
    public int Width { get; set; }
    public int Height { get; set; }
    public string? Created { get; set; }
    public string? Name { get; set; }
    public string? Mime { get; set; }
}

public sealed class StorageEstimate
{
    public double Usage { get; set; }
    public double Quota { get; set; }
}

public sealed record LayoutOption(string Id, string Label, int Slots, string Hint);
