# ASELY Photo Booth ♡

A cute retro photo booth that runs entirely in the browser: real camera, photo strips, video recording,
whole-session "Memory Reel", photo editor, video editor with baked-in decorations, local gallery, ZIP downloads, Web Share.
Built with Blazor WebAssembly (C#), Razor Components, CSS, and a small set of JavaScript modules for the browser APIs.

## Run it

Requirements: .NET 8 SDK (https://dotnet.microsoft.com/download).

    dotnet run

Open the address it prints (use `http://localhost:...`; the camera also works on localhost without https).
For a real deployment you need **https**, because browsers only allow the camera on secure pages:

    dotnet publish -c Release -o out      # static files end up in out/wwwroot

Upload `out/wwwroot` to any static host (Netlify, Cloudflare Pages, Azure Static Web Apps, GitHub Pages...).
`wwwroot/_headers` (Netlify / Cloudflare Pages) carries the real HTTP security headers (CSP, HSTS, Permissions-Policy);
`wwwroot/_redirects` makes deep links like /gallery work. On other hosts, set the same headers in their config.
If you host under a sub-path, change `<base href="/">` in `wwwroot/index.html`.

## Structure

    Pages/        Home, Studio, PhotoEditor, ReelEditor, Gallery, Privacy, About   (Razor Components)
    Components/   Sprite, Logo, Alert, Floaters
    Layout/       MainLayout (navigation + footer)
    Services/     BoothInterop (typed wrapper for the JS modules), BoothSession, Friendly (messages)
    Models/       MediaItem, DecoItem, PhotoComposition, ReelComposition ...
    wwwroot/css/app.css       design system: palette, spacing, radius as CSS variables in :root
    wwwroot/js/
      asely-camera.js   camera + MediaRecorder (camera logic, no editing code)
      asely-store.js    in-memory store + optional IndexedDB, delete-all
      asely-util.js     downloads, Web Share, ZIP writer, permission check
      asely-art.js      sprites, backgrounds, frames, filters, draggable stickers
      asely-editor.js   photo/strip composition + export (Canvas)
      asely-reel.js     video preview + export (canvas.captureStream + MediaRecorder)

## Privacy design

- No uploads, no accounts, no analytics, no third-party scripts; fonts are hosted locally (SIL OFL licenses in wwwroot/fonts).
- Camera only after "Start Camera"; microphone only when "Include sound" is switched on; REC badge + Stop always visible.
- Media is held in memory per tab. Browser storage (IndexedDB) is opt-in ("Keep on this device" / Privacy Center switch).
- Delete one, delete a session, or Delete All Memories (clears memory and IndexedDB).
- Optional email delivery is **not** implemented (it would need a backend); nothing is ever sent automatically.

## Notes

- Memory Reel export plays the video once in real time and records it, so keep the tab in front while it renders.
- MP4 is used when the browser can encode it (Chrome, Edge, Safari); otherwise WebM, and the UI says so.
- Only one recording at a time: Memory Reel is for Photo mode, clips are recorded in Video mode.
