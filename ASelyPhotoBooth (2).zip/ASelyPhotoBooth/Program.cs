using ASelyPhotoBooth;
using ASelyPhotoBooth.Services;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");

// Everything runs in the browser. There is no HttpClient registration on purpose:
// the app never needs to call a server.
builder.Services.AddScoped<BoothInterop>();
builder.Services.AddScoped<BoothSession>();

await builder.Build().RunAsync();
