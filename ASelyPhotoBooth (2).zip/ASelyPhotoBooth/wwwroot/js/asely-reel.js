/* ASELY Photo Booth - Memory Reel video editor.
 * Preview: the video is drawn to a canvas with all decorations in real time.
 * Export: the same drawing code renders every frame into a canvas stream that
 * MediaRecorder encodes, so the decorations are baked into the saved file.
 * The original recording is never modified. */
(function () {
  'use strict';
  const A = window.AselyArt;
  const I = window.AselyItems;
  const C = A.COLORS;

  const FRAMES = new Set(['none', 'camcorder', 'retro', 'pink', 'cream']);
  const LOOKS = new Set(['none', 'strawberry', 'vintage', 'softpink', 'lavender', 'warm']);

  const S = {
    canvas: null, ctx: null, video: null, dotnet: null, cfg: null, bounds: {}, selected: null,
    id: null, created: null, duration: 0, raf: 0, dirty: true, detach: null, lastTick: 0,
    noise: null, cancel: false, exporting: false, listeners: []
  };

  function normalize(c) {
    const n = (v, d, a, b) => (Number.isFinite(Number(v)) ? A.clamp(Number(v), a, b) : d);
    return {
      frame: FRAMES.has(c.frame) ? c.frame : 'none',
      look: LOOKS.has(c.look) ? c.look : 'none',
      grain: n(c.grain, 0, 0, 100),
      dateStamp: !!c.dateStamp,
      dateText: String(c.dateText || '').slice(0, 40),
      showRec: !!c.showRec,
      mirror: !!c.mirror,
      items: I.sanitize(c.items)
    };
  }

  function pickMime() {
    if (typeof MediaRecorder === 'undefined' || !MediaRecorder.isTypeSupported) return '';
    for (const m of ['video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/mp4', 'video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm']) {
      try { if (MediaRecorder.isTypeSupported(m)) return m; } catch (e) { }
    }
    return '';
  }

  function noiseCanvas() {
    if (S.noise) return S.noise;
    const c = A.makeCanvas(256, 256);
    const x = c.getContext('2d');
    const img = x.createImageData(256, 256);
    const r = A.rng(99);
    for (let i = 0; i < img.data.length; i += 4) {
      const v = Math.floor(r() * 255);
      img.data[i] = img.data[i + 1] = img.data[i + 2] = v; img.data[i + 3] = 255;
    }
    x.putImageData(img, 0, 0);
    S.noise = c;
    return c;
  }

  function overlay(ctx, W, H, color, alpha, mode) {
    ctx.save(); ctx.globalCompositeOperation = mode; ctx.globalAlpha = alpha; ctx.fillStyle = color; ctx.fillRect(0, 0, W, H); ctx.restore();
  }
  function vignette(ctx, W, H, amount) {
    const g = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.35, W / 2, H / 2, Math.max(W, H) * 0.75);
    g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, `rgba(40,25,40,${amount})`);
    ctx.save(); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H); ctx.restore();
  }
  function applyLook(ctx, W, H, look) {
    switch (look) {
      case 'strawberry': overlay(ctx, W, H, C.pink, 0.4, 'soft-light'); overlay(ctx, W, H, C.light, 0.1, 'screen'); break;
      case 'vintage': overlay(ctx, W, H, '#FFD6A0', 0.3, 'multiply'); overlay(ctx, W, H, '#2a1f2d', 0.1, 'screen'); vignette(ctx, W, H, 0.4); break;
      case 'softpink': overlay(ctx, W, H, C.light, 0.28, 'screen'); overlay(ctx, W, H, C.pink, 0.12, 'soft-light'); break;
      case 'lavender': overlay(ctx, W, H, C.lav, 0.38, 'soft-light'); overlay(ctx, W, H, C.lav, 0.1, 'screen'); break;
      case 'warm': overlay(ctx, W, H, C.butter, 0.26, 'soft-light'); overlay(ctx, W, H, C.cream, 0.08, 'screen'); break;
    }
  }
  function applyGrain(ctx, W, H, amount) {
    if (!amount) return;
    const pat = ctx.createPattern(noiseCanvas(), 'repeat');
    ctx.save();
    ctx.translate(Math.random() * 256, Math.random() * 256);
    ctx.globalCompositeOperation = 'overlay';
    ctx.globalAlpha = amount / 100 * 0.45;
    ctx.fillStyle = pat;
    ctx.fillRect(-256, -256, W + 512, H + 512);
    ctx.restore();
  }

  function border(ctx, W, H, t, r, color) {
    ctx.save();
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.rect(0, 0, W, H);
    ctx.moveTo(t + r, t);
    ctx.arcTo(W - t, t, W - t, H - t, r); ctx.arcTo(W - t, H - t, t, H - t, r);
    ctx.arcTo(t, H - t, t, t, r); ctx.arcTo(t, t, W - t, t, r);
    ctx.closePath(); ctx.fill('evenodd');
    ctx.restore();
  }

  /* returns the vertical space (px) the frame takes at the bottom, for placing the date stamp */
  function drawFrame(ctx, kind, W, H, t, cfg) {
    const m = Math.min(W, H);
    if (kind === 'camcorder') {
      const ins = m * 0.05, len = m * 0.08, lw = Math.max(2, m / 260);
      ctx.save();
      ctx.strokeStyle = '#FFFFFF'; ctx.lineWidth = lw; ctx.globalAlpha = 0.9; ctx.lineCap = 'round';
      ctx.shadowColor = 'rgba(0,0,0,0.5)'; ctx.shadowBlur = lw * 2;
      ctx.beginPath();
      ctx.moveTo(ins, ins + len); ctx.lineTo(ins, ins); ctx.lineTo(ins + len, ins);
      ctx.moveTo(W - ins - len, ins); ctx.lineTo(W - ins, ins); ctx.lineTo(W - ins, ins + len);
      ctx.moveTo(ins, H - ins - len); ctx.lineTo(ins, H - ins); ctx.lineTo(ins + len, H - ins);
      ctx.moveTo(W - ins - len, H - ins); ctx.lineTo(W - ins, H - ins); ctx.lineTo(W - ins, H - ins - len);
      ctx.moveTo(W / 2 - len / 2, H / 2); ctx.lineTo(W / 2 + len / 2, H / 2);
      ctx.moveTo(W / 2, H / 2 - len / 2); ctx.lineTo(W / 2, H / 2 + len / 2);
      ctx.stroke();
      ctx.fillStyle = '#FFFFFF'; ctx.shadowBlur = lw * 2;
      ctx.font = `700 ${Math.round(m * 0.045)}px ${A.FONTS.type}`; ctx.textBaseline = 'middle'; ctx.textAlign = 'left';
      if (cfg.showRec) {
        if (Math.floor(t * 2) % 2 === 0) { ctx.fillStyle = '#FF3B5C'; ctx.beginPath(); ctx.arc(ins * 1.9, ins * 1.9 + m * 0.01, m * 0.014, 0, Math.PI * 2); ctx.fill(); }
        ctx.fillStyle = '#FFFFFF'; ctx.fillText('REC', ins * 1.9 + m * 0.03, ins * 1.9 + m * 0.01);
      } else ctx.fillText('PLAY ▶', ins * 1.4, ins * 1.9);
      // battery
      const bw = m * 0.07, bh = m * 0.032, bx = W - ins * 1.4 - bw, by = ins * 1.9 - bh / 2;
      ctx.strokeRect(bx, by, bw, bh); ctx.fillRect(bx + bw, by + bh * 0.3, bw * 0.08, bh * 0.4);
      ctx.fillRect(bx + 3, by + 3, bw * 0.6, bh - 6);
      ctx.restore();
      vignette(ctx, W, H, 0.3);
      return m * 0.07;
    }
    if (kind === 'retro') {
      const b = m * 0.075;
      border(ctx, W, H, b, m * 0.03, C.mauve);
      ctx.save();
      ctx.strokeStyle = C.lav; ctx.lineWidth = Math.max(2, m / 300);
      A.rrPath(ctx, b * 0.5, b * 0.5, W - b, H - b, m * 0.03); ctx.stroke();
      for (const [x, y] of [[b * 0.5, b * 0.5], [W - b * 0.5, b * 0.5], [b * 0.5, H - b * 0.5], [W - b * 0.5, H - b * 0.5]]) {
        ctx.fillStyle = C.lav; ctx.strokeStyle = C.cream; ctx.beginPath(); ctx.arc(x, y, b * 0.16, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
      }
      const bw = b * 3.4, bh = b * 0.62;
      ctx.fillStyle = C.pink; A.rrPath(ctx, W / 2 - bw / 2, H - b / 2 - bh / 2, bw, bh, bh / 2); ctx.fill();
      ctx.fillStyle = C.mauve; ctx.font = `800 ${Math.round(bh * 0.6)}px ${A.FONTS.rounded}`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText('ASELY', W / 2 - bh * 0.5, H - b / 2 + 1);
      A.spriteAt(ctx, 'heart', W / 2 + bw * 0.28, H - b / 2, bh * 0.62, 0);
      ctx.restore();
      return b;
    }
    if (kind === 'pink') {
      const b = m * 0.06;
      border(ctx, W, H, b, m * 0.02, C.pink);
      ctx.save(); ctx.fillStyle = C.light;
      const r = b * 0.34, step = b * 0.8;
      for (let x = b; x < W - b + 1; x += step) { ctx.beginPath(); ctx.arc(x, b, r, 0, 7); ctx.fill(); ctx.beginPath(); ctx.arc(x, H - b, r, 0, 7); ctx.fill(); }
      for (let y = b; y < H - b + 1; y += step) { ctx.beginPath(); ctx.arc(b, y, r, 0, 7); ctx.fill(); ctx.beginPath(); ctx.arc(W - b, y, r, 0, 7); ctx.fill(); }
      ctx.strokeStyle = C.cream; ctx.lineWidth = Math.max(2, m / 280); ctx.setLineDash([m * 0.02, m * 0.015]); ctx.lineCap = 'round';
      A.rrPath(ctx, b * 0.5, b * 0.5, W - b, H - b, m * 0.015); ctx.stroke();
      ctx.restore();
      A.spriteAt(ctx, 'bow', b * 1.1, b * 1.1, b * 2.1, -12);
      A.spriteAt(ctx, 'heart', W - b * 0.9, H - b * 0.9, b * 1.5, 10);
      A.spriteAt(ctx, 'star', W - b * 0.9, b * 0.9, b * 1.2, 15);
      return b;
    }
    if (kind === 'cream') {
      const b = m * 0.05;
      border(ctx, W, H, b, m * 0.012, C.cream);
      ctx.save();
      ctx.strokeStyle = C.mauve; ctx.globalAlpha = 0.55; ctx.lineWidth = Math.max(2, m / 320); ctx.setLineDash([m * 0.012, m * 0.01]);
      A.rrPath(ctx, b * 0.45, b * 0.45, W - b * 0.9, H - b * 0.9, m * 0.01); ctx.stroke();
      ctx.restore();
      for (const [x, y] of [[b * 0.5, b * 0.5], [W - b * 0.5, b * 0.5], [b * 0.5, H - b * 0.5], [W - b * 0.5, H - b * 0.5]]) A.spriteAt(ctx, 'star', x, y, b * 0.85, 0);
      return b;
    }
    return 0;
  }

  function drawStamp(ctx, W, H, cfg, bottomPad) {
    if (!cfg.dateStamp) return;
    const m = Math.min(W, H);
    const text = cfg.dateText || AselyUtil.stamp(S.created, 'camcorder');
    ctx.save();
    ctx.font = `700 ${Math.round(m * 0.05)}px ${A.FONTS.type}`;
    ctx.textAlign = 'right'; ctx.textBaseline = 'alphabetic';
    ctx.fillStyle = '#FF9A3C';
    ctx.shadowColor = 'rgba(40,20,0,0.75)'; ctx.shadowBlur = m * 0.01; ctx.shadowOffsetX = m * 0.003; ctx.shadowOffsetY = m * 0.003;
    ctx.fillText(text, W - m * 0.05 - bottomPad * 0.3, H - bottomPad - m * 0.025);
    ctx.restore();
  }

  /* Draws one finished frame: video + look + grain + frame + stamp + items. */
  function paintFrame(ctx, video, W, H, cfg, t, selected, k, collectBounds) {
    ctx.save();
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H);
    if (video && video.readyState >= 2) {
      if (cfg.mirror) { ctx.translate(W, 0); ctx.scale(-1, 1); }
      ctx.drawImage(video, 0, 0, W, H);
    }
    ctx.restore();
    applyLook(ctx, W, H, cfg.look);
    applyGrain(ctx, W, H, cfg.grain);
    const pad = drawFrame(ctx, cfg.frame, W, H, t, cfg);
    drawStamp(ctx, W, H, cfg, pad);
    const bounds = {};
    for (const it of cfg.items) bounds[it.id] = I.draw(ctx, it, W, H);
    if (selected && bounds[selected]) I.drawSelection(ctx, bounds[selected], k || 1);
    if (collectBounds) S.bounds = bounds;
  }

  function kScale() {
    const c = S.canvas;
    return c && c.clientWidth ? Math.max(1, c.width / c.clientWidth) : 1;
  }

  function redraw() {
    if (!S.canvas || !S.cfg || !S.video) return;
    paintFrame(S.ctx, S.video, S.canvas.width, S.canvas.height, S.cfg, S.video.currentTime || 0, S.selected, kScale(), true);
  }

  function loop() {
    S.raf = requestAnimationFrame(loop);
    if (!S.video || S.exporting) return;
    if (S.dirty || !S.video.paused || S.cfg && S.cfg.grain) { redraw(); S.dirty = false; }
  }

  function notify(force) {
    if (!S.dotnet || !S.video) return;
    const now = performance.now();
    if (!force && now - S.lastTick < 200) return;
    S.lastTick = now;
    try { S.dotnet.invokeMethodAsync('OnPlayback', S.video.currentTime || 0, S.duration, S.video.paused); } catch (e) { }
  }

  function on(target, type, fn) { target.addEventListener(type, fn); S.listeners.push(() => target.removeEventListener(type, fn)); }

  async function fixDuration(v, fallback) {
    if (Number.isFinite(v.duration) && v.duration > 0) return v.duration;
    // MediaRecorder files often report Infinity until the end is reached
    await new Promise(res => {
      const done = () => { v.removeEventListener('timeupdate', done); res(); };
      v.addEventListener('timeupdate', done);
      try { v.currentTime = 1e7; } catch (e) { res(); }
      setTimeout(done, 3000);
    });
    const d = Number.isFinite(v.duration) && v.duration > 0 ? v.duration : fallback || 0;
    try { v.currentTime = 0; } catch (e) { }
    return d;
  }

  async function openVideo(v, url) {
    v.preload = 'auto';
    v.playsInline = true;
    v.src = url;
    await new Promise((res, rej) => {
      v.onloadedmetadata = () => res();
      v.onerror = () => rej(new Error('video_unreadable'));
    });
    v.onloadedmetadata = null; v.onerror = null;
  }

  const AselyReel = {
    init(canvasId, videoId, dotnetRef) {
      this.dispose();
      S.canvas = document.getElementById(canvasId);
      S.video = document.getElementById(videoId);
      if (!S.canvas || !S.video) return false;
      S.ctx = S.canvas.getContext('2d');
      S.dotnet = dotnetRef;
      S.cfg = normalize({});
      S.detach = I.attach(S.canvas, {
        items: () => (S.cfg ? S.cfg.items : []),
        bounds: () => S.bounds,
        selected: () => S.selected,
        select: id => { S.selected = id; S.dirty = true; },
        redraw: () => { S.dirty = true; redraw(); },
        commit: () => { try { S.dotnet.invokeMethodAsync('OnItemsChanged', JSON.stringify(S.cfg.items), S.selected || ''); } catch (e) { } },
        remove: id => { S.cfg.items = S.cfg.items.filter(i => i.id !== id); S.selected = null; redraw(); try { S.dotnet.invokeMethodAsync('OnItemsChanged', JSON.stringify(S.cfg.items), ''); } catch (e) { } },
        kScale
      });
      on(S.video, 'timeupdate', () => { S.dirty = true; notify(false); });
      on(S.video, 'seeked', () => { S.dirty = true; notify(true); });
      on(S.video, 'play', () => notify(true));
      on(S.video, 'pause', () => notify(true));
      on(S.video, 'ended', () => notify(true));
      on(S.video, 'loadeddata', () => { S.dirty = true; });
      S.raf = requestAnimationFrame(loop);
      return true;
    },

    async load(id) {
      await AselyUtil.loadFonts();
      const meta = (await AselyStore.list()).find(m => m.id === id);
      if (!meta) throw new Error('not_found');
      const url = await AselyStore.objectUrl(id);
      S.video.pause();
      await openVideo(S.video, url);
      S.duration = await fixDuration(S.video, meta.duration);
      const vw = S.video.videoWidth || 1280, vh = S.video.videoHeight || 720;
      const scale = Math.min(1, 960 / vw);
      S.canvas.width = Math.max(2, Math.round(vw * scale / 2) * 2);
      S.canvas.height = Math.max(2, Math.round(vh * scale / 2) * 2);
      S.id = id; S.created = meta.created; S.dirty = true; S.selected = null;
      try { await S.video.play(); S.video.pause(); S.video.currentTime = 0; } catch (e) { }
      redraw();
      return { duration: S.duration, width: vw, height: vh, created: meta.created, name: meta.name, mime: meta.mime };
    },

    setConfig(json, selectedId) {
      if (!S.cfg) return false;
      S.cfg = normalize(JSON.parse(json));
      S.selected = selectedId && S.cfg.items.some(i => i.id === selectedId) ? selectedId : null;
      S.dirty = true;
      redraw();
      return true;
    },

    setSelected(id) { S.selected = id || null; S.dirty = true; redraw(); return true; },

    async play() { try { await S.video.play(); return true; } catch (e) { return false; } },
    pause() { S.video.pause(); return true; },
    seek(t) { S.video.currentTime = A.clamp(t, 0, S.duration || 0); S.dirty = true; return true; },
    exportMime() { return pickMime(); },

    cancelExport() { S.cancel = true; return true; },

    /* Renders the whole video with every decoration baked in. */
    async exportReel(configJson, sessionId, onProgressRef) {
      if (S.exporting) throw new Error('busy');
      if (typeof MediaRecorder === 'undefined' || !HTMLCanvasElement.prototype.captureStream) throw new Error('unsupported');
      const mime = pickMime();
      if (!mime) throw new Error('unsupported');
      const cfg = normalize(JSON.parse(configJson));
      S.exporting = true; S.cancel = false;
      if (S.video) S.video.pause();

      const meta = (await AselyStore.list()).find(m => m.id === S.id);
      if (!meta) { S.exporting = false; throw new Error('not_found'); }
      const url = await AselyStore.objectUrl(S.id);
      const v = document.createElement('video');
      let audioCtx = null;
      try {
        await openVideo(v, url);
        const duration = await fixDuration(v, meta.duration);
        const vw = v.videoWidth || 1280, vh = v.videoHeight || 720;
        const scale = Math.min(1, 1280 / Math.max(vw, vh));
        const W = Math.max(2, Math.round(vw * scale / 2) * 2), H = Math.max(2, Math.round(vh * scale / 2) * 2);
        const canvas = A.makeCanvas(W, H);
        const ctx = canvas.getContext('2d');
        paintFrame(ctx, v, W, H, cfg, 0, null, 1, false);
        const stream = canvas.captureStream(30);

        // route the original audio into the exported file (never to the speakers)
        try {
          const AC = window.AudioContext || window.webkitAudioContext;
          if (AC) {
            audioCtx = new AC();
            try { await audioCtx.resume(); } catch (e) { }
            if (audioCtx.state === 'running') {
              const src = audioCtx.createMediaElementSource(v);
              const dest = audioCtx.createMediaStreamDestination();
              src.connect(dest);
              dest.stream.getAudioTracks().forEach(t => stream.addTrack(t));
            } else { audioCtx.close(); audioCtx = null; }
          }
        } catch (e) { audioCtx = null; }

        const chunks = [];
        let rec;
        try { rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 6000000 }); }
        catch (e) { rec = new MediaRecorder(stream); }
        rec.ondataavailable = ev => { if (ev.data && ev.data.size) chunks.push(ev.data); };
        let recErr = null;
        rec.onerror = ev => { recErr = ev; };
        const stopped = new Promise(res => { rec.onstop = () => res(); });
        rec.start(500);

        v.currentTime = 0;
        await v.play();
        let lastReport = 0;
        await new Promise((resolve) => {
          const tick = () => {
            if (S.cancel || v.ended || v.paused && v.currentTime >= duration - 0.05) { resolve(); return; }
            paintFrame(ctx, v, W, H, cfg, v.currentTime, null, 1, false);
            const now = performance.now();
            if (onProgressRef && now - lastReport > 200) {
              lastReport = now;
              try { onProgressRef.invokeMethodAsync('OnExportProgress', Math.min(99, Math.round(v.currentTime / Math.max(0.1, duration) * 100))); } catch (e) { }
            }
            requestAnimationFrame(tick);
          };
          v.addEventListener('ended', () => resolve(), { once: true });
          requestAnimationFrame(tick);
        });
        if (!S.cancel) paintFrame(ctx, v, W, H, cfg, v.currentTime, null, 1, false);
        await new Promise(r => setTimeout(r, 250));
        v.pause();
        if (rec.state !== 'inactive') rec.stop();
        await stopped;
        stream.getTracks().forEach(t => t.stop());

        if (S.cancel) throw new Error('cancelled');
        if (recErr || chunks.length === 0) throw new Error('export_failed');
        const type = (rec.mimeType || mime).split(';')[0] || 'video/webm';
        const blob = new Blob(chunks, { type });
        const out = await AselyStore.put({
          sessionId: sessionId || meta.sessionId, kind: 'reel', origin: 'editor', duration,
          name: `asely-memory-reel-${AselyUtil.stamp(null, 'file')}`
        }, blob);
        out.fallback = !type.includes('mp4');
        try { onProgressRef && onProgressRef.invokeMethodAsync('OnExportProgress', 100); } catch (e) { }
        return out;
      } finally {
        S.exporting = false;
        try { v.pause(); v.removeAttribute('src'); v.load(); } catch (e) { }
        if (audioCtx) { try { audioCtx.close(); } catch (e) { } }
        S.dirty = true;
      }
    },

    dispose() {
      cancelAnimationFrame(S.raf);
      S.listeners.forEach(f => f()); S.listeners = [];
      if (S.detach) { S.detach(); S.detach = null; }
      if (S.video) { try { S.video.pause(); S.video.removeAttribute('src'); S.video.load(); } catch (e) { } }
      S.canvas = null; S.ctx = null; S.video = null; S.dotnet = null; S.cfg = null; S.bounds = {}; S.selected = null; S.id = null;
      return true;
    }
  };

  window.AselyReel = AselyReel;
})();
