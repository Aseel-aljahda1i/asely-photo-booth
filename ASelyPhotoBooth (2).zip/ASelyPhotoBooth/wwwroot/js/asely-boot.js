/* Tiny helpers that must live outside inline HTML because of the strict Content Security Policy. */
(function () {
  'use strict';
  const dismiss = document.querySelector('#blazor-error-ui .dismiss');
  if (dismiss) {
    const hide = () => { document.getElementById('blazor-error-ui').style.display = 'none'; };
    dismiss.addEventListener('click', hide);
    dismiss.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') hide(); });
  }
})();
