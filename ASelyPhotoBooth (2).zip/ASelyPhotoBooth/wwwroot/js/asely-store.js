/* ASELY Photo Booth - local media store.
 * Everything lives in this tab's memory. Items are written to IndexedDB (on this
 * device only) when the person explicitly keeps them, or when they turned on the
 * "keep my memories in this browser" switch in the Privacy Center.
 * Nothing in this file talks to a network. */
(function () {
  'use strict';

  const DB_NAME = 'asely-memories';
  const STORE = 'media';
  const AUTO_KEY = 'asely.keepOnDevice';

  const mem = new Map();   // id -> { meta, blob }
  const urls = new Map();  // id -> object URL
  let dbPromise = null;
  let loaded = false;

  const LIMITS = {
    image: { types: ['image/jpeg', 'image/png', 'image/webp'], max: 20 * 1024 * 1024 },
    video: { types: ['video/mp4', 'video/webm', 'video/quicktime'], max: 700 * 1024 * 1024 }
  };

  function newId() {
    if (window.crypto && crypto.randomUUID) return crypto.randomUUID().replace(/-/g, '').slice(0, 16);
    const a = new Uint8Array(8);
    crypto.getRandomValues(a);
    return Array.from(a, b => b.toString(16).padStart(2, '0')).join('');
  }

  function openDb() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      if (!('indexedDB' in window)) { reject(new Error('idb_unavailable')); return; }
      let req;
      try { req = indexedDB.open(DB_NAME, 1); } catch (e) { reject(new Error('idb_unavailable')); return; }
      req.onupgradeneeded = () => { req.result.createObjectStore(STORE, { keyPath: 'id' }); };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(new Error('idb_unavailable'));
      req.onblocked = () => reject(new Error('idb_unavailable'));
    });
    dbPromise.catch(() => { dbPromise = null; });
    return dbPromise;
  }

  async function dbRun(mode, fn) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const t = db.transaction(STORE, mode);
      const s = t.objectStore(STORE);
      let req;
      try { req = fn(s); } catch (e) { reject(e); return; }
      t.oncomplete = () => resolve(req ? req.result : undefined);
      t.onabort = () => reject(t.error || new Error('aborted'));
      t.onerror = () => reject(t.error || new Error('aborted'));
    });
  }

  function isQuota(e) {
    return e && (e.name === 'QuotaExceededError' || e.code === 22 || /quota/i.test(e.message || ''));
  }

  async function init() {
    if (loaded) return;
    loaded = true;
    try {
      const rows = await dbRun('readonly', s => s.getAll());
      for (const row of rows || []) {
        if (!mem.has(row.id)) {
          const { blob, ...meta } = row;
          meta.persisted = true;
          mem.set(row.id, { meta, blob });
        }
      }
    } catch (e) { /* storage not available: memory-only mode */ }
  }

  function cleanMeta(m) { return Object.assign({}, m); }

  const AselyStore = {
    newId,

    async init() { await init(); },

    getAutoSave() {
      try { return localStorage.getItem(AUTO_KEY) === '1'; } catch (e) { return false; }
    },
    setAutoSave(on) {
      try { if (on) localStorage.setItem(AUTO_KEY, '1'); else localStorage.removeItem(AUTO_KEY); } catch (e) { }
      return on;
    },

    async put(meta, blob) {
      await init();
      const m = Object.assign({
        id: newId(), sessionId: 'none', kind: 'photo', mime: blob.type, size: blob.size,
        created: new Date().toISOString(), name: '', duration: 0, persisted: false, origin: '', persistFailed: false
      }, meta);
      m.mime = blob.type || m.mime;
      m.size = blob.size;
      mem.set(m.id, { meta: m, blob });
      if (this.getAutoSave()) {
        try { await this.persist(m.id); } catch (e) { m.persistFailed = true; }
      }
      return cleanMeta(m);
    },

    async list() {
      await init();
      return Array.from(mem.values()).map(x => cleanMeta(x.meta))
        .sort((a, b) => (a.created < b.created ? -1 : a.created > b.created ? 1 : 0));
    },

    has(id) { return mem.has(id); },

    async getBlob(id) {
      await init();
      const x = mem.get(id);
      if (!x) throw new Error('not_found');
      return x.blob;
    },

    async objectUrl(id) {
      await init();
      const x = mem.get(id);
      if (!x) return '';
      if (!urls.has(id)) urls.set(id, URL.createObjectURL(x.blob));
      return urls.get(id);
    },

    async persist(id) {
      await init();
      const x = mem.get(id);
      if (!x) throw new Error('not_found');
      try {
        await dbRun('readwrite', s => s.put(Object.assign({}, x.meta, { persisted: true, persistFailed: false, blob: x.blob })));
      } catch (e) {
        if (isQuota(e)) throw new Error('storage_full');
        throw new Error('idb_unavailable');
      }
      x.meta.persisted = true;
      x.meta.persistFailed = false;
      return true;
    },

    async unpersist(id) {
      const x = mem.get(id);
      try { await dbRun('readwrite', s => s.delete(id)); } catch (e) { /* nothing stored */ }
      if (x) x.meta.persisted = false;
      return true;
    },

    async remove(id) {
      await init();
      const u = urls.get(id);
      if (u) { URL.revokeObjectURL(u); urls.delete(id); }
      mem.delete(id);
      try { await dbRun('readwrite', s => s.delete(id)); } catch (e) { }
      return true;
    },

    async removeMany(ids) {
      for (const id of ids) await this.remove(id);
      return true;
    },

    /* Delete All Memories: memory, IndexedDB and every object URL. */
    async clearAll() {
      for (const u of urls.values()) URL.revokeObjectURL(u);
      urls.clear();
      mem.clear();
      try { await dbRun('readwrite', s => s.clear()); } catch (e) { }
      try {
        if (window.indexedDB && indexedDB.deleteDatabase) {
          const db = await dbPromise; if (db) db.close();
          dbPromise = null; loaded = true;
          indexedDB.deleteDatabase(DB_NAME);
        }
      } catch (e) { }
      return true;
    },

    async estimate() {
      try {
        if (navigator.storage && navigator.storage.estimate) {
          const e = await navigator.storage.estimate();
          return { usage: e.usage || 0, quota: e.quota || 0 };
        }
      } catch (e) { }
      return { usage: 0, quota: 0 };
    },

    /* Import files from an <input type="file"> after validating type and size. */
    async importFiles(inputId, sessionId, group) {
      const input = document.getElementById(inputId);
      if (!input || !input.files) return [];
      const rule = LIMITS[group];
      if (!rule) throw new Error('invalid_type');
      const files = Array.from(input.files);
      const out = [];
      try {
        for (const f of files) {
          if (!rule.types.includes(f.type)) throw new Error('invalid_type');
          if (f.size > rule.max) throw new Error('too_large');
          if (f.size === 0) throw new Error('invalid_type');
        }
        for (const f of files) {
          const isVideo = group === 'video';
          const meta = await this.put({
            sessionId, kind: isVideo ? 'video' : 'photo', origin: 'import',
            name: f.name.replace(/[^\w.\- ]+/g, '_').slice(0, 80)
          }, f);
          if (isVideo) meta.duration = 0;
          out.push(meta);
        }
      } finally {
        input.value = '';
      }
      return out;
    }
  };

  window.AselyStore = AselyStore;
})();
