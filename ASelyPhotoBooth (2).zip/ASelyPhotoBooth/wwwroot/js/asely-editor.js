/* ASELY Photo Booth - photo / strip editor.
 * The Blazor page owns the editing state and sends it here as JSON; this file
 * renders it with the Canvas API and exports the real decorated image. */
(function () {
  'use strict';
  const A = window.AselyArt;
  const I = window.AselyItems;

  const FILTERS = new Set(Object.keys(A.PRESETS));
  const LAYOUTS = new Set(['single', 'strip2', 'strip3', 'strip4', 'grid4']);

  const S = {
    canvas: null, ctx: null, dotnet: null, comp: null, bounds: {}, selected: null,
    bitmaps: new Map(), slotCache: new Map(), detach: null, token: 0
  };

  function normalize(c) {
    const layout = LAYOUTS.has(c.layout) ? c.layout : 'single';
    const L = A.layoutOf(layout);
    const slots = [];
    for (let i = 0; i < L.slots.length; i++) {
      const v = Array.isArray(c.slots) ? c.slots[i] : null;
      slots.push(typeof v === 'string' && /^[\w-]{1,40}$/.test(v) ? v : null);
    }
    const n = (v, d, a, b) => (Number.isFinite(Number(v)) ? A.clamp(Number(v), a, b) : d);
    return {
      layout, slots,
      frame: A.FRAME_OK.has(c.frame) ? c.frame : 'polaroid',
      background: String(c.background || 'solid:#F9DDE5'),
      filter: FILTERS.has(c.filter) ? c.filter : 'none',
      brightness: n(c.brightness, 100, 50, 150), contrast: n(c.contrast, 100, 50, 150), saturation: n(c.saturation, 100, 0, 200),
      beauty: n(c.beauty, 40, 0, 100),
      caption: String(c.caption || '').slice(0, 40),
      showDate: !!c.showDate,
      dateText: String(c.dateText || '').slice(0, 40),
      items: I.sanitize(c.items)
    };
  }

  async function bitmapFor(id) {
    if (S.bitmaps.has(id)) return S.bitmaps.get(id);
    const blob = await AselyStore.getBlob(id);
    const bm = await createImageBitmap(blob);
    S.bitmaps.set(id, bm);
    return bm;
  }

  function slotCanvas(id, w, h, comp) {
    const key = [id, w, h, comp.filter, comp.brightness, comp.contrast, comp.saturation, comp.filter === 'beauty' ? comp.beauty : 0].join('|');
    if (S.slotCache.has(key)) return S.slotCache.get(key);
    const base = A.makeCanvas(w, h);
    A.drawCover(base.getContext('2d'), S.bitmaps.get(id), 0, 0, w, h);
    const out = A.applyFilter(base, comp.filter, comp.brightness, comp.contrast, comp.saturation, comp.beauty / 100);
    if (S.slotCache.size > 14) S.slotCache.delete(S.slotCache.keys().next().value);
    S.slotCache.set(key, out);
    return out;
  }

  function drawPlaceholder(ctx, s) {
    ctx.save();
    A.rrPath(ctx, s.x, s.y, s.w, s.h, 22);
    ctx.fillStyle = '#FFFFFF'; ctx.globalAlpha = 0.65; ctx.fill(); ctx.globalAlpha = 1;
    ctx.strokeStyle = A.COLORS.pink; ctx.lineWidth = 6; ctx.setLineDash([22, 16]); ctx.stroke(); ctx.setLineDash([]);
    A.spriteAt(ctx, 'camera', s.x + s.w / 2, s.y + s.h / 2 - 20, Math.min(s.w, s.h) * 0.3, 0);
    ctx.fillStyle = A.COLORS.mauve; ctx.font = `700 ${Math.round(Math.min(s.w, s.h) * 0.075)}px ${A.FONTS.rounded}`;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText('Pick a photo', s.x + s.w / 2, s.y + s.h / 2 + Math.min(s.w, s.h) * 0.22);
    ctx.restore();
  }

  function fitText(ctx, text, maxW, startPx, family, weight) {
    let px = startPx;
    ctx.font = `${weight} ${px}px ${family}`;
    while (px > 14 && ctx.measureText(text).width > maxW) { px -= 2; ctx.font = `${weight} ${px}px ${family}`; }
    return px;
  }

  /* Paints a full composition. Returns bounds of the draggable items. */
  function paintTo(ctx, comp, selected, k) {
    const L = A.layoutOf(comp.layout);
    const W = L.W, H = L.H;
    ctx.clearRect(0, 0, W, H);
    A.paintBackground(ctx, comp.background, W, H);
    A.frameUnder(ctx, comp.frame, L);

    const radius = A.frameRadius(comp.frame);
    L.slots.forEach((s, i) => {
      const id = comp.slots[i];
      if (id && S.bitmaps.has(id)) {
        const c = slotCanvas(id, s.w, s.h, comp);
        ctx.save();
        A.rrPath(ctx, s.x, s.y, s.w, s.h, radius);
        ctx.clip();
        ctx.drawImage(c, s.x, s.y);
        ctx.restore();
      } else drawPlaceholder(ctx, s);
    });

    A.frameOver(ctx, comp.frame, L);

    // footer: caption + date/time label
    const f = L.footer;
    ctx.save();
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = A.COLORS.mauve;
    const maxW = W - L.margin * 2.4;
    if (comp.caption) {
      const px = fitText(ctx, comp.caption, maxW, Math.round(f.h * 0.4), A.FONTS.hand, 700);
      ctx.fillText(comp.caption, W / 2, f.y + f.h * (comp.showDate ? 0.38 : 0.5));
      void px;
    }
    if (comp.showDate) {
      const label = comp.dateText || AselyUtil.stamp(null, 'full');
      fitText(ctx, label, maxW, Math.round(f.h * 0.18), A.FONTS.type, 700);
      ctx.globalAlpha = 0.85;
      ctx.fillText(label, W / 2, f.y + f.h * (comp.caption ? 0.78 : 0.5));
    }
    ctx.restore();

    const bounds = {};
    for (const it of comp.items) bounds[it.id] = I.draw(ctx, it, W, H);
    if (selected && bounds[selected]) I.drawSelection(ctx, bounds[selected], k || 1);
    return bounds;
  }

  function kScale() {
    const c = S.canvas;
    return c && c.clientWidth ? Math.max(1, c.width / c.clientWidth) : 1;
  }

  function paintSync() {
    if (!S.canvas || !S.comp) return;
    const L = A.layoutOf(S.comp.layout);
    if (S.canvas.width !== L.W || S.canvas.height !== L.H) { S.canvas.width = L.W; S.canvas.height = L.H; }
    S.bounds = paintTo(S.ctx, S.comp, S.selected, kScale());
  }

  function commit() {
    if (!S.dotnet) return;
    try { S.dotnet.invokeMethodAsync('OnItemsChanged', JSON.stringify(S.comp.items), S.selected || ''); } catch (e) { }
  }

  const AselyEditor = {
    init(canvasId, dotnetRef) {
      this.dispose();
      S.canvas = document.getElementById(canvasId);
      if (!S.canvas) return false;
      S.ctx = S.canvas.getContext('2d');
      S.dotnet = dotnetRef;
      S.detach = I.attach(S.canvas, {
        items: () => (S.comp ? S.comp.items : []),
        bounds: () => S.bounds,
        selected: () => S.selected,
        select: id => { S.selected = id; },
        redraw: paintSync,
        commit,
        remove: id => { S.comp.items = S.comp.items.filter(i => i.id !== id); S.selected = null; paintSync(); commit(); },
        kScale
      });
      return true;
    },

    async render(json, selectedId) {
      const my = ++S.token;
      await AselyUtil.loadFonts();
      const comp = normalize(JSON.parse(json));
      for (const id of comp.slots) {
        if (id && !S.bitmaps.has(id)) {
          try { await bitmapFor(id); } catch (e) { /* photo was deleted: slot shows placeholder */ }
        }
      }
      if (my !== S.token) return false;
      S.comp = comp;
      S.selected = selectedId && comp.items.some(i => i.id === selectedId) ? selectedId : null;
      paintSync();
      return true;
    },

    setSelected(id) { S.selected = id || null; paintSync(); return true; },

    async exportBlob(type) {
      if (!S.comp) throw new Error('nothing_to_export');
      const L = A.layoutOf(S.comp.layout);
      const c = A.makeCanvas(L.W, L.H);
      paintTo(c.getContext('2d'), S.comp, null, 1);
      const mime = type === 'image/jpeg' ? 'image/jpeg' : 'image/png';
      return new Promise((res, rej) => c.toBlob(b => b ? res(b) : rej(new Error('export_failed')), mime, 0.95));
    },

    async save(sessionId, name) {
      const blob = await this.exportBlob('image/png');
      const kind = S.comp.layout === 'single' ? 'photo' : 'strip';
      return AselyStore.put({ sessionId, kind, origin: 'editor', name }, blob);
    },

    async download(filename) {
      const blob = await this.exportBlob('image/png');
      AselyUtil.downloadBlob(blob, filename);
      return true;
    },

    async share(filename) {
      const blob = await this.exportBlob('image/png');
      return AselyUtil.shareBlob(blob, filename, 'My ASELY photo');
    },

    dispose() {
      if (S.detach) { S.detach(); S.detach = null; }
      for (const bm of S.bitmaps.values()) { try { bm.close(); } catch (e) { } }
      S.bitmaps.clear(); S.slotCache.clear();
      S.canvas = null; S.ctx = null; S.dotnet = null; S.comp = null; S.bounds = {}; S.selected = null; S.token++;
      return true;
    },

    forgetPhoto(id) {
      const bm = S.bitmaps.get(id);
      if (bm) { try { bm.close(); } catch (e) { } S.bitmaps.delete(id); }
      S.slotCache.clear();
    }
  };

  window.AselyEditor = AselyEditor;
})();
