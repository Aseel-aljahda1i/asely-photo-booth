/* ASELY Photo Booth - downloads, sharing and ZIP creation (all local). */
(function () {
  'use strict';

  const pad = n => String(n).padStart(2, '0');

  function extFor(mime) {
    const m = (mime || '').toLowerCase();
    if (m.includes('mp4')) return 'mp4';
    if (m.includes('webm')) return 'webm';
    if (m.includes('quicktime')) return 'mov';
    if (m.includes('png')) return 'png';
    if (m.includes('webp')) return 'webp';
    if (m.includes('jpeg') || m.includes('jpg')) return 'jpg';
    return 'bin';
  }

  function stamp(iso, style) {
    const d = iso ? new Date(iso) : new Date();
    const y = d.getFullYear(), mo = pad(d.getMonth() + 1), da = pad(d.getDate());
    const h24 = d.getHours(), mi = pad(d.getMinutes());
    if (style === 'file') return `${y}${mo}${da}-${pad(h24)}${mi}${pad(d.getSeconds())}`;
    if (style === 'date') return `${y}.${mo}.${da}`;
    if (style === 'camcorder') {
      const h12 = h24 % 12 || 12;
      return `${y}/${mo}/${da}  ${pad(h12)}:${mi} ${h24 >= 12 ? 'PM' : 'AM'}`;
    }
    return `${y}.${mo}.${da}  ${pad(h24)}:${mi}`;
  }

  function saveBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.rel = 'noopener';
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { a.remove(); URL.revokeObjectURL(url); }, 4000);
  }

  function canShareFiles() {
    try {
      if (!navigator.share || !navigator.canShare) return false;
      const f = new File([new Blob(['a'], { type: 'text/plain' })], 'a.txt', { type: 'text/plain' });
      return navigator.canShare({ files: [f] });
    } catch (e) { return false; }
  }

  async function shareBlob(blob, filename, title) {
    if (!canShareFiles()) return 'unsupported';
    const file = new File([blob], filename, { type: blob.type });
    if (!navigator.canShare({ files: [file] })) return 'unsupported';
    try {
      await navigator.share({ files: [file], title: title || 'ASELY Photo Booth' });
      return 'shared';
    } catch (e) {
      if (e && e.name === 'AbortError') return 'cancelled';
      return 'error';
    }
  }

  /* ---------- ZIP (store method, no compression, no dependencies) ---------- */
  let crcTable = null;
  function crc32(bytes) {
    if (!crcTable) {
      crcTable = new Uint32Array(256);
      for (let n = 0; n < 256; n++) {
        let c = n;
        for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
        crcTable[n] = c >>> 0;
      }
    }
    let crc = 0xFFFFFFFF;
    for (let i = 0; i < bytes.length; i++) crc = crcTable[(crc ^ bytes[i]) & 0xFF] ^ (crc >>> 8);
    return (crc ^ 0xFFFFFFFF) >>> 0;
  }

  function dosDateTime(d) {
    const time = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1);
    const date = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
    return { time, date };
  }

  async function buildZip(entries) {
    const enc = new TextEncoder();
    const chunks = [];
    const central = [];
    let offset = 0;
    const now = dosDateTime(new Date());
    let total = 0;

    for (const e of entries) {
      const data = new Uint8Array(await e.blob.arrayBuffer());
      total += data.length;
      if (total > 1.8 * 1024 * 1024 * 1024) throw new Error('zip_too_large');
      const name = enc.encode(e.name);
      const crc = crc32(data);

      const lh = new DataView(new ArrayBuffer(30));
      lh.setUint32(0, 0x04034b50, true);
      lh.setUint16(4, 20, true);
      lh.setUint16(6, 0x0800, true);        // UTF-8 names
      lh.setUint16(8, 0, true);             // store
      lh.setUint16(10, now.time, true);
      lh.setUint16(12, now.date, true);
      lh.setUint32(14, crc, true);
      lh.setUint32(18, data.length, true);
      lh.setUint32(22, data.length, true);
      lh.setUint16(26, name.length, true);
      lh.setUint16(28, 0, true);
      chunks.push(new Uint8Array(lh.buffer), name, data);

      const ch = new DataView(new ArrayBuffer(46));
      ch.setUint32(0, 0x02014b50, true);
      ch.setUint16(4, 20, true);
      ch.setUint16(6, 20, true);
      ch.setUint16(8, 0x0800, true);
      ch.setUint16(10, 0, true);
      ch.setUint16(12, now.time, true);
      ch.setUint16(14, now.date, true);
      ch.setUint32(16, crc, true);
      ch.setUint32(20, data.length, true);
      ch.setUint32(24, data.length, true);
      ch.setUint16(28, name.length, true);
      ch.setUint32(42, offset, true);
      central.push(new Uint8Array(ch.buffer), name);

      offset += 30 + name.length + data.length;
    }

    let centralSize = 0;
    for (const c of central) centralSize += c.length;

    const end = new DataView(new ArrayBuffer(22));
    end.setUint32(0, 0x06054b50, true);
    end.setUint16(8, entries.length, true);
    end.setUint16(10, entries.length, true);
    end.setUint32(12, centralSize, true);
    end.setUint32(16, offset, true);

    return new Blob([...chunks, ...central, new Uint8Array(end.buffer)], { type: 'application/zip' });
  }

  const AselyUtil = {
    extFor,
    stamp(iso, style) { return stamp(iso || null, style || 'full'); },
    canShareFiles,

    async permission(name) {
      try {
        if (!navigator.permissions || !navigator.permissions.query) return 'unknown';
        const r = await navigator.permissions.query({ name });
        return r.state;
      } catch (e) { return 'unknown'; }
    },
    async loadFonts() {
      try {
        if (!document.fonts || !document.fonts.load) return true;
        await Promise.all(['800 40px "Baloo 2"', '700 40px Nunito', '700 40px Caveat'].map(f => document.fonts.load(f)));
      } catch (e) { }
      return true;
    },

    async downloadById(id, filename) {
      const blob = await AselyStore.getBlob(id);
      saveBlob(blob, filename);
      return true;
    },
    downloadBlob(blob, filename) { saveBlob(blob, filename); return true; },

    async shareById(id, filename, title) {
      const blob = await AselyStore.getBlob(id);
      return shareBlob(blob, filename, title);
    },
    shareBlob,

    buildZip,

    /* Download the given stored items as one ZIP. Returns the number of files. */
    async downloadZip(ids, zipName) {
      const metas = (await AselyStore.list()).filter(m => ids.includes(m.id));
      if (metas.length === 0) throw new Error('nothing_to_zip');
      const used = new Set();
      const entries = [];
      for (const m of metas) {
        let base = (m.name && m.name.trim()) ? m.name.trim() : `asely-${m.kind}-${stamp(m.created, 'file')}`;
        const ext = extFor(m.mime);
        base = base.replace(/\.[a-z0-9]{2,4}$/i, '').replace(/[\\/:*?"<>|]+/g, '_');
        let name = `${base}.${ext}`, i = 2;
        while (used.has(name.toLowerCase())) name = `${base}-${i++}.${ext}`;
        used.add(name.toLowerCase());
        entries.push({ name, blob: await AselyStore.getBlob(m.id) });
      }
      const zip = await buildZip(entries);
      saveBlob(zip, zipName || `asely-memories-${stamp(null, 'file')}.zip`);
      return entries.length;
    }
  };

  window.AselyUtil = AselyUtil;
})();
