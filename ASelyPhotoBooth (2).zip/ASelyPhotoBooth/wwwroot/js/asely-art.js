/* ASELY Photo Booth - shared canvas artwork:
 * sprites (read from the inline SVG sprite sheet), strip layouts, backgrounds,
 * frames, photo filters and draggable sticker/text items.
 * Pure drawing code: no network, no face detection, no analysis of people. */
(function () {
  'use strict';

  const C = { pink: '#F3AFC4', cream: '#FFF5E9', lav: '#C9B5E8', butter: '#F7D66D', mauve: '#554653', light: '#F9DDE5' };

  const FONTS = {
    rounded: '"Baloo 2","Nunito","Varela Round","Arial Rounded MT Bold",ui-rounded,"Segoe UI",system-ui,sans-serif',
    hand: '"Caveat","Patrick Hand","Segoe Print","Bradley Hand","Chalkboard SE","Comic Sans MS",cursive',
    type: '"Courier New",Courier,ui-monospace,monospace',
    serif: 'Georgia,"Times New Roman",serif',
    bold: '"Arial Black","Helvetica Neue",Arial,sans-serif'
  };
  const fontStack = id => FONTS[id] || FONTS.rounded;

  function rng(seed) {
    let a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  function rrPath(ctx, x, y, w, h, r) {
    r = Math.max(0, Math.min(r, w / 2, h / 2));
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  /* ---------- sprites ---------- */
  const spriteCache = new Map();
  function sprite(id) {
    if (spriteCache.has(id)) return spriteCache.get(id);
    const el = document.getElementById('s-' + id);
    const parts = el ? Array.from(el.querySelectorAll('path')).map(p => ({
      path: new Path2D(p.getAttribute('d')),
      fill: p.getAttribute('fill') || 'none',
      stroke: p.getAttribute('stroke') || 'none',
      sw: parseFloat(p.getAttribute('stroke-width') || '0'),
      cap: p.getAttribute('stroke-linecap') || 'butt',
      join: p.getAttribute('stroke-linejoin') || 'miter',
      op: parseFloat(p.getAttribute('opacity') || '1')
    })) : [];
    if (parts.length) spriteCache.set(id, parts);
    return parts;
  }
  /* Draws a sprite centred on the origin, `size` px wide. */
  function drawSprite(ctx, id, size) {
    const parts = sprite(id);
    if (!parts.length) return;
    ctx.save();
    const s = size / 100;
    ctx.scale(s, s);
    ctx.translate(-50, -50);
    const base = ctx.globalAlpha;
    for (const p of parts) {
      ctx.globalAlpha = base * p.op;
      if (p.fill !== 'none') { ctx.fillStyle = p.fill; ctx.fill(p.path); }
      if (p.stroke !== 'none' && p.sw > 0) {
        ctx.strokeStyle = p.stroke; ctx.lineWidth = p.sw; ctx.lineCap = p.cap; ctx.lineJoin = p.join;
        ctx.stroke(p.path);
      }
    }
    ctx.restore();
  }
  function spriteAt(ctx, id, x, y, size, rotDeg, alpha) {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate((rotDeg || 0) * Math.PI / 180);
    if (alpha != null) ctx.globalAlpha *= alpha;
    drawSprite(ctx, id, size);
    ctx.restore();
  }

  /* ---------- strip / photo layouts ---------- */
  function stripLayout(n) {
    const W = 900, margin = 60, sw = 780, sh = 585, gap = 36;
    const slots = [];
    for (let i = 0; i < n; i++) slots.push({ x: margin, y: margin + i * (sh + gap), w: sw, h: sh });
    const end = margin + n * sh + (n - 1) * gap;
    const footer = { y: end + 30, h: 190 };
    return { W, H: footer.y + footer.h + 30, margin, slots, footer };
  }
  function layoutOf(id) {
    switch (id) {
      case 'single':
        return { W: 1080, H: 1440, margin: 90, slots: [{ x: 90, y: 90, w: 900, h: 1000 }], footer: { y: 1130, h: 250 } };
      case 'strip2': return stripLayout(2);
      case 'strip4': return stripLayout(4);
      case 'grid4': {
        const m = 80, s = 500, g = 40;
        const slots = [];
        for (let r = 0; r < 2; r++) for (let c = 0; c < 2; c++) slots.push({ x: m + c * (s + g), y: m + r * (s + g), w: s, h: s });
        return { W: 1200, H: 1500, margin: m, slots, footer: { y: m + 2 * s + g + 40, h: 240 } };
      }
      default: return stripLayout(3);
    }
  }

  /* ---------- backgrounds ---------- */
  const BG_OK = new Set([
    'solid:#F9DDE5', 'solid:#FFF5E9', 'solid:#C9B5E8', 'solid:#F7D66D', 'solid:#F3AFC4',
    'gingham:pink', 'gingham:lavender', 'dots:cream', 'stripes:cream', 'dots:lavender', 'stripes:lavender',
    'scrap:hearts', 'scrap:grid', 'scrap:stars', 'scrap:flowers'
  ]);

  function gingham(ctx, W, H, color, base) {
    ctx.fillStyle = base; ctx.fillRect(0, 0, W, H);
    const s = Math.max(22, Math.round(W / 20));
    ctx.fillStyle = color;
    ctx.globalAlpha = 0.45;
    for (let x = 0; x < W; x += s * 2) ctx.fillRect(x, 0, s, H);
    for (let y = 0; y < H; y += s * 2) ctx.fillRect(0, y, W, s);
    ctx.globalAlpha = 1;
  }
  function dots(ctx, W, H, base, color) {
    ctx.fillStyle = base; ctx.fillRect(0, 0, W, H);
    const s = Math.max(44, Math.round(W / 14));
    ctx.fillStyle = color;
    for (let y = 0, row = 0; y < H + s; y += s, row++) {
      for (let x = (row % 2) * s / 2; x < W + s; x += s) {
        ctx.beginPath(); ctx.arc(x, y, s * 0.14, 0, Math.PI * 2); ctx.fill();
      }
    }
  }
  function stripes(ctx, W, H, base, color) {
    ctx.fillStyle = base; ctx.fillRect(0, 0, W, H);
    const s = Math.max(30, Math.round(W / 24));
    ctx.fillStyle = color; ctx.globalAlpha = 0.55;
    for (let x = 0; x < W; x += s * 2) ctx.fillRect(x, 0, s, H);
    ctx.globalAlpha = 1;
  }
  function scatter(ctx, W, H, ids, seed, density, alpha) {
    const r = rng(seed);
    const cell = Math.max(120, Math.round(W / 6));
    const count = Math.round((W * H) / (cell * cell) * density);
    for (let i = 0; i < count; i++) {
      const id = ids[Math.floor(r() * ids.length)];
      spriteAt(ctx, id, r() * W, r() * H, W * (0.05 + r() * 0.07), (r() - 0.5) * 50, alpha);
    }
  }
  function paintBackground(ctx, id, W, H) {
    if (!BG_OK.has(id)) id = 'solid:#FFF5E9';
    const [kind, arg] = id.split(':');
    ctx.save();
    if (kind === 'solid') { ctx.fillStyle = arg; ctx.fillRect(0, 0, W, H); }
    else if (kind === 'gingham') {
      if (arg === 'pink') gingham(ctx, W, H, C.pink, '#FFF7F9'); else gingham(ctx, W, H, C.lav, '#FBF8FF');
    } else if (kind === 'dots') {
      if (arg === 'cream') dots(ctx, W, H, C.cream, C.pink); else dots(ctx, W, H, '#F1EAFB', C.lav);
    } else if (kind === 'stripes') {
      if (arg === 'cream') stripes(ctx, W, H, C.cream, C.light); else stripes(ctx, W, H, '#F6F1FD', C.lav);
    } else if (kind === 'scrap') {
      if (arg === 'hearts') { ctx.fillStyle = C.light; ctx.fillRect(0, 0, W, H); scatter(ctx, W, H, ['heart', 'star', 'sparkle'], 11, 1.1, 0.55); }
      else if (arg === 'stars') { ctx.fillStyle = '#EADFF8'; ctx.fillRect(0, 0, W, H); scatter(ctx, W, H, ['star', 'sparkle', 'heart'], 23, 1.1, 0.6); }
      else if (arg === 'flowers') { ctx.fillStyle = C.cream; ctx.fillRect(0, 0, W, H); scatter(ctx, W, H, ['flower', 'heart', 'butterfly', 'strawberry'], 37, 1.0, 0.55); }
      else {
        ctx.fillStyle = C.cream; ctx.fillRect(0, 0, W, H);
        const g = Math.max(36, Math.round(W / 24));
        ctx.strokeStyle = C.lav; ctx.globalAlpha = 0.5; ctx.lineWidth = 2;
        ctx.beginPath();
        for (let x = g; x < W; x += g) { ctx.moveTo(x, 0); ctx.lineTo(x, H); }
        for (let y = g; y < H; y += g) { ctx.moveTo(0, y); ctx.lineTo(W, y); }
        ctx.stroke();
        ctx.strokeStyle = C.pink; ctx.globalAlpha = 0.9; ctx.lineWidth = 3;
        ctx.beginPath(); ctx.moveTo(g * 2, 0); ctx.lineTo(g * 2, H); ctx.stroke();
      }
    }
    ctx.restore();
  }

  /* ---------- frames ---------- */
  const FRAME_OK = new Set(['none', 'minimal', 'polaroid', 'camera', 'scrapbook', 'floral', 'film']);

  function evenOddBorder(ctx, W, H, t, r, color) {
    ctx.save();
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.rect(0, 0, W, H);
    ctx.moveTo(t + r, t);
    ctx.arcTo(W - t, t, W - t, H - t, r);
    ctx.arcTo(W - t, H - t, t, H - t, r);
    ctx.arcTo(t, H - t, t, t, r);
    ctx.arcTo(t, t, W - t, t, r);
    ctx.closePath();
    ctx.fill('evenodd');
    ctx.restore();
  }

  function frameRadius(frame) {
    return ({ none: 26, minimal: 14, polaroid: 10, camera: 8, scrapbook: 18, floral: 18, film: 4 })[frame] ?? 16;
  }

  /* Drawn before the photos (cards, shadows). */
  function frameUnder(ctx, frame, L) {
    const { W, H, margin } = L;
    if (frame === 'polaroid') {
      const m = margin * 0.34;
      ctx.save();
      ctx.shadowColor = 'rgba(85,70,83,0.28)'; ctx.shadowBlur = 36; ctx.shadowOffsetY = 12;
      ctx.fillStyle = '#FFFFFF';
      rrPath(ctx, m, m, W - 2 * m, H - 2 * m, 26); ctx.fill();
      ctx.restore();
    } else if (frame === 'minimal') {
      ctx.save();
      ctx.fillStyle = '#FFFFFF';
      ctx.shadowColor = 'rgba(85,70,83,0.18)'; ctx.shadowBlur = 16; ctx.shadowOffsetY = 5;
      for (const s of L.slots) { rrPath(ctx, s.x - 12, s.y - 12, s.w + 24, s.h + 24, 22); ctx.fill(); }
      ctx.restore();
    } else if (frame === 'none') {
      ctx.save();
      ctx.shadowColor = 'rgba(85,70,83,0.2)'; ctx.shadowBlur = 20; ctx.shadowOffsetY = 6;
      ctx.fillStyle = '#FFFFFF';
      for (const s of L.slots) { rrPath(ctx, s.x, s.y, s.w, s.h, 26); ctx.fill(); }
      ctx.restore();
    }
  }

  /* Drawn after the photos (borders, decorations). */
  function frameOver(ctx, frame, L) {
    const { W, H, margin, slots } = L;
    ctx.save();
    if (frame === 'minimal') {
      ctx.strokeStyle = C.mauve; ctx.globalAlpha = 0.5; ctx.lineWidth = 3;
      rrPath(ctx, 16, 16, W - 32, H - 32, 20); ctx.stroke();
    } else if (frame === 'camera') {
      const t = margin * 0.5;
      evenOddBorder(ctx, W, H, t, 14, C.mauve);
      ctx.strokeStyle = C.lav; ctx.lineWidth = 3; ctx.globalAlpha = 0.9;
      rrPath(ctx, t * 0.5, t * 0.5, W - t, H - t, 12); ctx.stroke();
      ctx.globalAlpha = 1;
      for (const [x, y] of [[t * 0.5, t * 0.5], [W - t * 0.5, t * 0.5], [t * 0.5, H - t * 0.5], [W - t * 0.5, H - t * 0.5]]) {
        ctx.fillStyle = C.lav; ctx.strokeStyle = C.cream; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(x, y, t * 0.2, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
      }
      // badge on the top edge
      const bw = 190, bh = t * 0.62;
      ctx.fillStyle = C.pink;
      rrPath(ctx, W / 2 - bw / 2, t / 2 - bh / 2, bw, bh, bh / 2); ctx.fill();
      ctx.fillStyle = C.mauve; ctx.font = `800 ${Math.round(bh * 0.62)}px ${FONTS.rounded}`;
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText('ASELY', W / 2 - 12, t / 2 + 1);
      spriteAt(ctx, 'heart', W / 2 + 56, t / 2, bh * 0.6, 0);
      // viewfinder corners on every photo
      ctx.strokeStyle = C.cream; ctx.lineWidth = 5; ctx.lineCap = 'round'; ctx.globalAlpha = 0.85;
      const len = 34, ins = 18;
      for (const s of slots) {
        const x0 = s.x + ins, y0 = s.y + ins, x1 = s.x + s.w - ins, y1 = s.y + s.h - ins;
        ctx.beginPath();
        ctx.moveTo(x0, y0 + len); ctx.lineTo(x0, y0); ctx.lineTo(x0 + len, y0);
        ctx.moveTo(x1 - len, y0); ctx.lineTo(x1, y0); ctx.lineTo(x1, y0 + len);
        ctx.moveTo(x0, y1 - len); ctx.lineTo(x0, y1); ctx.lineTo(x0 + len, y1);
        ctx.moveTo(x1 - len, y1); ctx.lineTo(x1, y1); ctx.lineTo(x1, y1 - len);
        ctx.stroke();
      }
    } else if (frame === 'scrapbook') {
      const t = margin * 0.55;
      evenOddBorder(ctx, W, H, t, 20, C.pink);
      ctx.fillStyle = C.light;
      const r = t * 0.36, step = t * 0.8;
      for (let x = t; x < W - t + 1; x += step) { ctx.beginPath(); ctx.arc(x, t, r, 0, Math.PI * 2); ctx.fill(); ctx.beginPath(); ctx.arc(x, H - t, r, 0, Math.PI * 2); ctx.fill(); }
      for (let y = t; y < H - t + 1; y += step) { ctx.beginPath(); ctx.arc(t, y, r, 0, Math.PI * 2); ctx.fill(); ctx.beginPath(); ctx.arc(W - t, y, r, 0, Math.PI * 2); ctx.fill(); }
      // stitches
      ctx.strokeStyle = C.cream; ctx.lineWidth = 4; ctx.setLineDash([14, 12]); ctx.lineCap = 'round';
      rrPath(ctx, t * 0.5, t * 0.5, W - t, H - t, 16); ctx.stroke();
      ctx.setLineDash([]);
      // washi tape
      const tape = (x, y, rot, color) => {
        ctx.save(); ctx.translate(x, y); ctx.rotate(rot * Math.PI / 180);
        ctx.globalAlpha = 0.85; ctx.fillStyle = color; ctx.fillRect(-95, -28, 190, 56);
        ctx.globalAlpha = 0.5; ctx.fillStyle = '#FFFFFF';
        for (let i = -90; i < 90; i += 28) { ctx.beginPath(); ctx.moveTo(i, -28); ctx.lineTo(i + 12, -28); ctx.lineTo(i - 4, 28); ctx.lineTo(i - 16, 28); ctx.closePath(); ctx.fill(); }
        ctx.restore();
      };
      tape(t * 0.9, t * 0.9, -35, C.butter);
      tape(W - t * 0.9, H - t * 0.9, -35, C.lav);
      spriteAt(ctx, 'heart', W - t * 0.7, t * 0.7, t * 1.2, 12);
      spriteAt(ctx, 'bow', t * 0.7, H - t * 0.7, t * 1.5, -10);
    } else if (frame === 'floral') {
      const t = margin * 0.7;
      const r = rng(77);
      ctx.strokeStyle = C.cream; ctx.lineWidth = 6;
      rrPath(ctx, t * 0.95, t * 0.95, W - t * 1.9, H - t * 1.9, 18); ctx.globalAlpha = 0.9; ctx.stroke();
      ctx.globalAlpha = 1;
      const step = t * 1.25;
      const put = (x, y, i) => {
        if (i % 3 === 2) spriteAt(ctx, i % 2 ? 'heart' : 'sparkle', x, y, t * 0.6, (r() - 0.5) * 40);
        else spriteAt(ctx, 'flower', x, y, t * (0.95 + r() * 0.2), (r() - 0.5) * 60);
      };
      let i = 0;
      for (let x = t * 0.5; x < W; x += step) { put(x, t * 0.5, i++); put(x + step / 2, H - t * 0.5, i++); }
      for (let y = t * 1.6; y < H - t; y += step) { put(t * 0.5, y, i++); put(W - t * 0.5, y + step / 2, i++); }
      spriteAt(ctx, 'butterfly', W - t * 0.9, t * 1.1, t * 1.7, 15);
      spriteAt(ctx, 'butterfly', t * 0.9, H - t * 1.1, t * 1.4, -20);
    } else if (frame === 'film') {
      const bw = margin * 0.9;
      ctx.fillStyle = '#2B2229';
      ctx.fillRect(0, 0, bw, H); ctx.fillRect(W - bw, 0, bw, H);
      ctx.fillStyle = C.cream;
      const hw = bw * 0.42, hh = bw * 0.56, hs = bw * 1.15;
      for (let y = hs * 0.4; y < H - hh; y += hs) {
        rrPath(ctx, (bw - hw) / 2, y, hw, hh, 6); ctx.fill();
        rrPath(ctx, W - bw + (bw - hw) / 2, y, hw, hh, 6); ctx.fill();
      }
      ctx.strokeStyle = '#2B2229'; ctx.lineWidth = 6;
      for (const s of slots) { ctx.strokeRect(s.x - 3, s.y - 3, s.w + 6, s.h + 6); }
      ctx.fillStyle = C.butter; ctx.font = `700 ${Math.round(bw * 0.26)}px ${FONTS.type}`; ctx.textBaseline = 'middle'; ctx.textAlign = 'left';
      ctx.save(); ctx.translate(W - bw * 0.12, H - bw * 1.2); ctx.rotate(-Math.PI / 2);
      ctx.fillText('ASELY 400  ▷ 12   ▷ 13   ▷ 14', 0, 0); ctx.restore();
    }
    ctx.restore();
  }

  /* ---------- photo filters (pure pixel maths so they work in every browser) ---------- */
  const PRESETS = {
    none: {},
    strawberry: { mul: [1.02, 0.95, 0.98], add: [8, 0, 6], sat: 1.12, con: 0.96, bri: 1.06, lift: 10, tint: [243, 175, 196, 0.14], vig: 0.1 },
    vintage: { mul: [1.04, 0.97, 0.86], add: [10, 6, 0], sat: 0.8, con: 0.92, bri: 1.0, lift: 18, tint: [255, 214, 160, 0.12], vig: 0.35, grain: 0.1 },
    softpink: { mul: [1.0, 0.97, 0.99], add: [10, 4, 8], sat: 0.92, con: 0.88, bri: 1.1, lift: 14, tint: [249, 221, 229, 0.22], vig: 0.06 },
    warmcream: { mul: [1.05, 1.02, 0.9], add: [8, 6, 0], sat: 1.0, con: 0.96, bri: 1.06, lift: 8, tint: [255, 245, 233, 0.18], vig: 0.08 },
    lavender: { mul: [0.98, 0.96, 1.04], add: [4, 0, 12], sat: 0.95, con: 0.94, bri: 1.05, lift: 12, tint: [201, 181, 232, 0.2], vig: 0.1 },
    classic: { sat: 0.82, con: 1.18, bri: 0.98, vig: 0.4, grain: 0.07 },
    beauty: { sat: 1.04, con: 0.96, bri: 1.04, lift: 4 }
  };

  function makeCanvas(w, h) {
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(w)); c.height = Math.max(1, Math.round(h));
    return c;
  }

  /* Returns a NEW canvas with the filter applied. beautyAmt is 0..1 and only used by the 'beauty' filter. */
  function applyFilter(src, presetId, bri, con, sat, beautyAmt) {
    const W = src.width, H = src.height;
    const out = makeCanvas(W, H);
    const ctx = out.getContext('2d', { willReadFrequently: true });
    ctx.drawImage(src, 0, 0);
    const p = Object.assign({}, PRESETS[presetId] || {});
    const userNeutral = bri === 100 && con === 100 && sat === 100;
    if ((presetId === 'none' || !PRESETS[presetId]) && userNeutral) return out;

    if (presetId === 'beauty') {
      // soft-focus glow: a blurred copy blended in gently. No face detection of any kind.
      const small = makeCanvas(W / 6, H / 6);
      const sctx = small.getContext('2d');
      sctx.imageSmoothingQuality = 'high';
      sctx.drawImage(src, 0, 0, small.width, small.height);
      ctx.imageSmoothingQuality = 'high';
      ctx.globalAlpha = 0.5 * clamp(beautyAmt, 0, 1);
      ctx.drawImage(small, 0, 0, W, H);
      ctx.globalAlpha = 1;
      p.bri = 1 + 0.06 * clamp(beautyAmt, 0, 1);
      p.sat = 1 + 0.06 * clamp(beautyAmt, 0, 1);
      p.con = 1 - 0.06 * clamp(beautyAmt, 0, 1);
    }

    const img = ctx.getImageData(0, 0, W, H);
    const d = img.data;
    const [mr, mg, mb] = p.mul || [1, 1, 1];
    const [ar, ag, ab] = p.add || [0, 0, 0];
    const tint = p.tint || [0, 0, 0, 0];
    const S = (p.sat ?? 1) * (sat / 100);
    const Cn = (p.con ?? 1) * (con / 100);
    const B = (p.bri ?? 1) * (bri / 100);
    const lift = p.lift || 0;
    const vig = p.vig || 0;
    const grain = p.grain || 0;
    const rnd = rng(1234);
    const lf = 1 - lift / 255;

    for (let i = 0, px = 0; i < d.length; i += 4, px++) {
      let r = d[i] * mr + ar, g = d[i + 1] * mg + ag, b = d[i + 2] * mb + ab;
      if (tint[3]) { r += (tint[0] - r) * tint[3]; g += (tint[1] - g) * tint[3]; b += (tint[2] - b) * tint[3]; }
      const l = 0.299 * r + 0.587 * g + 0.114 * b;
      r = l + (r - l) * S; g = l + (g - l) * S; b = l + (b - l) * S;
      r = ((r - 128) * Cn + 128) * B; g = ((g - 128) * Cn + 128) * B; b = ((b - 128) * Cn + 128) * B;
      if (lift) { r = r * lf + lift; g = g * lf + lift; b = b * lf + lift; }
      if (vig) {
        const x = (px % W) / W - 0.5, y = ((px / W) | 0) / H - 0.5;
        const f = 1 - vig * Math.min(1, (x * x + y * y) * 3.2);
        r *= f; g *= f; b *= f;
      }
      if (grain) { const n = (rnd() - 0.5) * 255 * grain; r += n; g += n; b += n; }
      d[i] = r < 0 ? 0 : r > 255 ? 255 : r;
      d[i + 1] = g < 0 ? 0 : g > 255 ? 255 : g;
      d[i + 2] = b < 0 ? 0 : b > 255 ? 255 : b;
    }
    ctx.putImageData(img, 0, 0);
    return out;
  }

  function drawCover(ctx, img, x, y, w, h) {
    const iw = img.width, ih = img.height;
    const s = Math.max(w / iw, h / ih);
    const sw = w / s, sh = h / s;
    ctx.drawImage(img, (iw - sw) / 2, (ih - sh) / 2, sw, sh, x, y, w, h);
  }

  /* ---------- draggable items (stickers and text) ---------- */
  function itemFont(it, W) {
    const px = Math.max(8, Math.round(it.size * W));
    const weight = it.font === 'hand' ? 700 : it.font === 'type' ? 700 : 800;
    return { px, css: `${weight} ${px}px ${fontStack(it.font)}` };
  }

  const AselyItems = {
    /* Draws one item and returns its bounds {cx,cy,w,h,rot(rad)} in canvas px. */
    draw(ctx, it, W, H) {
      const cx = it.x * W, cy = it.y * H, rot = (it.rot || 0) * Math.PI / 180;
      let w, h;
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(rot);
      if (it.type === 'sticker') {
        w = h = Math.max(10, it.size * W);
        ctx.shadowColor = 'rgba(85,70,83,0.22)'; ctx.shadowBlur = w * 0.05; ctx.shadowOffsetY = w * 0.02;
        drawSprite(ctx, it.sprite, w);
      } else {
        const f = itemFont(it, W);
        ctx.font = f.css;
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        const text = String(it.text || '').slice(0, 80) || ' ';
        w = ctx.measureText(text).width + f.px * 0.4;
        h = f.px * 1.35;
        if (it.type === 'date') {
          ctx.shadowColor = 'rgba(255,140,40,0.55)'; ctx.shadowBlur = f.px * 0.25;
        } else {
          ctx.shadowColor = 'rgba(85,70,83,0.28)'; ctx.shadowBlur = f.px * 0.12; ctx.shadowOffsetY = f.px * 0.04;
        }
        ctx.fillStyle = /^#[0-9a-fA-F]{6}$/.test(it.color || '') ? it.color : C.mauve;
        ctx.fillText(text, 0, 0);
      }
      ctx.restore();
      return { cx, cy, w, h, rot };
    },

    handles(b, k) {
      const off = 26 * k;
      const lp = (lx, ly) => {
        const c = Math.cos(b.rot), s = Math.sin(b.rot);
        return { x: b.cx + lx * c - ly * s, y: b.cy + lx * s + ly * c };
      };
      return {
        del: lp(-b.w / 2, -b.h / 2),
        resize: lp(b.w / 2, b.h / 2),
        rotate: lp(0, -b.h / 2 - off * 1.4)
      };
    },

    drawSelection(ctx, b, k) {
      const hr = 11 * k;
      const hd = AselyItems.handles(b, k);
      ctx.save();
      ctx.translate(b.cx, b.cy); ctx.rotate(b.rot);
      ctx.strokeStyle = C.mauve; ctx.lineWidth = 2 * k; ctx.setLineDash([7 * k, 5 * k]);
      ctx.strokeRect(-b.w / 2, -b.h / 2, b.w, b.h);
      ctx.setLineDash([]);
      ctx.beginPath(); ctx.moveTo(0, -b.h / 2); ctx.lineTo(0, -b.h / 2 - 26 * k * 1.4); ctx.stroke();
      ctx.restore();
      const dot = (p, fill, glyph) => {
        ctx.save();
        ctx.fillStyle = fill; ctx.strokeStyle = C.mauve; ctx.lineWidth = 2 * k;
        ctx.beginPath(); ctx.arc(p.x, p.y, hr, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
        ctx.fillStyle = C.mauve; ctx.font = `700 ${Math.round(13 * k)}px ${FONTS.bold}`;
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(glyph, p.x, p.y + 1 * k);
        ctx.restore();
      };
      dot(hd.del, C.pink, '×');
      dot(hd.resize, C.butter, '⤡');
      dot(hd.rotate, C.lav, '↻');
    },

    hit(items, bounds, x, y) {
      for (let i = items.length - 1; i >= 0; i--) {
        const b = bounds[items[i].id];
        if (!b) continue;
        const dx = x - b.cx, dy = y - b.cy;
        const c = Math.cos(-b.rot), s = Math.sin(-b.rot);
        const lx = dx * c - dy * s, ly = dx * s + dy * c;
        if (Math.abs(lx) <= b.w / 2 + 6 && Math.abs(ly) <= b.h / 2 + 6) return items[i].id;
      }
      return null;
    },

    /* Never trust incoming data: only known types, finite numbers, bounded text. */
    sanitize(list) {
      const out = [];
      if (!Array.isArray(list)) return out;
      for (const raw of list.slice(0, 60)) {
        if (!raw || typeof raw !== 'object') continue;
        const type = raw.type === 'text' || raw.type === 'date' ? raw.type : raw.type === 'sticker' ? 'sticker' : null;
        if (!type) continue;
        const num = (v, d, a, b) => (Number.isFinite(Number(v)) ? clamp(Number(v), a, b) : d);
        const it = {
          id: String(raw.id || '').replace(/[^\w-]/g, '').slice(0, 40) || ('i' + out.length),
          type,
          sprite: /^[a-z]{2,20}$/.test(raw.sprite || '') ? raw.sprite : 'heart',
          text: String(raw.text || '').slice(0, 80),
          font: FONTS[raw.font] ? raw.font : 'rounded',
          color: /^#[0-9a-fA-F]{6}$/.test(raw.color || '') ? raw.color : C.mauve,
          size: type === 'sticker' ? num(raw.size, 0.18, 0.04, 0.9) : num(raw.size, 0.06, 0.015, 0.25),
          x: num(raw.x, 0.5, 0, 1), y: num(raw.y, 0.5, 0, 1), rot: num(raw.rot, 0, -180, 180)
        };
        out.push(it);
      }
      return out;
    },

    /* Pointer interaction for dragging, resizing and rotating items on a canvas.
     * api: items(), bounds(), selected(), select(id), redraw(), commit(), remove(id), kScale() */
    attach(canvas, api) {
      let mode = null, startPt = null, startItem = null, grab = null;
      const pt = e => {
        const r = canvas.getBoundingClientRect();
        return { x: (e.clientX - r.left) * canvas.width / r.width, y: (e.clientY - r.top) * canvas.height / r.height };
      };
      const near = (a, b, r) => Math.hypot(a.x - b.x, a.y - b.y) <= r;

      function down(e) {
        if (e.button !== undefined && e.button !== 0) return;
        const p = pt(e), k = api.kScale();
        const sel = api.selected();
        const items = api.items();
        const it = items.find(i => i.id === sel);
        const b = it && api.bounds()[it.id];
        if (it && b) {
          const hd = AselyItems.handles(b, k);
          const r = 20 * k;
          if (near(p, hd.del, r)) { api.remove(it.id); e.preventDefault(); return; }
          if (near(p, hd.resize, r)) { mode = 'resize'; startItem = Object.assign({}, it); startPt = { d: Math.hypot(p.x - b.cx, p.y - b.cy) || 1 }; canvas.setPointerCapture(e.pointerId); e.preventDefault(); return; }
          if (near(p, hd.rotate, r)) { mode = 'rotate'; startItem = Object.assign({}, it); startPt = { a: Math.atan2(p.y - b.cy, p.x - b.cx) }; canvas.setPointerCapture(e.pointerId); e.preventDefault(); return; }
        }
        const id = AselyItems.hit(items, api.bounds(), p.x, p.y);
        api.select(id);
        if (id) {
          const t = items.find(i => i.id === id), tb = api.bounds()[id];
          mode = 'move'; startItem = Object.assign({}, t); grab = { dx: p.x - tb.cx, dy: p.y - tb.cy };
          canvas.setPointerCapture(e.pointerId);
          e.preventDefault();
        }
        api.redraw();
        if (!id) api.commit();
      }
      function move(e) {
        const p = pt(e), k = api.kScale();
        if (!mode) {
          const sel = api.selected();
          const it = api.items().find(i => i.id === sel);
          const b = it && api.bounds()[sel];
          let cur = 'default';
          if (it && b) {
            const hd = AselyItems.handles(b, k);
            if (near(p, hd.del, 20 * k)) cur = 'pointer';
            else if (near(p, hd.resize, 20 * k)) cur = 'nwse-resize';
            else if (near(p, hd.rotate, 20 * k)) cur = 'grab';
          }
          if (cur === 'default' && AselyItems.hit(api.items(), api.bounds(), p.x, p.y)) cur = 'move';
          canvas.style.cursor = cur;
          return;
        }
        const it = api.items().find(i => i.id === api.selected());
        if (!it) return;
        const b = api.bounds()[it.id];
        if (mode === 'move') {
          it.x = clamp((p.x - grab.dx) / canvas.width, 0, 1);
          it.y = clamp((p.y - grab.dy) / canvas.height, 0, 1);
        } else if (mode === 'resize') {
          const d = Math.hypot(p.x - b.cx, p.y - b.cy) || 1;
          const lim = it.type === 'sticker' ? [0.04, 0.9] : [0.015, 0.25];
          it.size = clamp(startItem.size * d / startPt.d, lim[0], lim[1]);
        } else if (mode === 'rotate') {
          const a = Math.atan2(p.y - b.cy, p.x - b.cx);
          let deg = startItem.rot + (a - startPt.a) * 180 / Math.PI;
          deg = ((deg % 360) + 540) % 360 - 180;
          for (const snap of [-180, -90, 0, 90, 180]) if (Math.abs(deg - snap) < 4) deg = snap;
          it.rot = deg;
        }
        api.redraw();
        e.preventDefault();
      }
      function up(e) {
        if (!mode) return;
        mode = null;
        try { canvas.releasePointerCapture(e.pointerId); } catch (err) { }
        api.commit();
      }
      canvas.addEventListener('pointerdown', down);
      canvas.addEventListener('pointermove', move);
      canvas.addEventListener('pointerup', up);
      canvas.addEventListener('pointercancel', up);
      return () => {
        canvas.removeEventListener('pointerdown', down);
        canvas.removeEventListener('pointermove', move);
        canvas.removeEventListener('pointerup', up);
        canvas.removeEventListener('pointercancel', up);
      };
    }
  };

  /* Paints little previews into <canvas data-sticker="heart"> and <canvas data-bg="gingham:pink"> */
  function paintThumbs() {
    document.querySelectorAll('canvas[data-sticker]').forEach(c => {
      const ctx = c.getContext('2d');
      ctx.clearRect(0, 0, c.width, c.height);
      ctx.save(); ctx.translate(c.width / 2, c.height / 2);
      drawSprite(ctx, c.getAttribute('data-sticker'), Math.min(c.width, c.height) * 0.9);
      ctx.restore();
    });
    document.querySelectorAll('canvas[data-bg]').forEach(c => {
      const ctx = c.getContext('2d');
      ctx.save(); ctx.scale(c.width / 300, c.width / 300);
      paintBackground(ctx, c.getAttribute('data-bg'), 300, 300 * c.height / c.width);
      ctx.restore();
    });
    return true;
  }

  window.AselyArt = {
    COLORS: C, FONTS, fontStack, rng, clamp, rrPath, makeCanvas,
    sprite, drawSprite, spriteAt, layoutOf, paintBackground,
    frameUnder, frameOver, frameRadius, FRAME_OK, applyFilter, PRESETS, drawCover, paintThumbs
  };
  window.AselyItems = AselyItems;
})();
