/* ASELY Photo Booth - camera, photo capture and MediaRecorder logic.
 * Camera permission is requested only inside start(), which the UI calls after
 * the person presses "Start Camera". Microphone permission is requested only
 * inside enableMic(), which the UI calls when the person ticks "Include sound". */
(function () {
  'use strict';

  let videoEl = null;
  let camStream = null;
  let micStream = null;
  let facing = 'user';

  let rec = null;
  let chunks = [];
  let recMime = '';
  let recStarted = 0;
  let pausedAt = 0;
  let pausedTotal = 0;
  let recError = null;
  let recMeta = null;

  function mapError(e) {
    const n = (e && e.name) || '';
    if (n === 'NotAllowedError' || n === 'SecurityError' || n === 'PermissionDeniedError') return 'denied';
    if (n === 'NotFoundError' || n === 'DevicesNotFoundError') return 'notfound';
    if (n === 'NotReadableError' || n === 'TrackStartError' || n === 'AbortError') return 'inuse';
    if (n === 'OverconstrainedError' || n === 'ConstraintNotSatisfiedError') return 'constraint';
    return 'unknown';
  }

  function stopStream(s) {
    if (!s) return;
    s.getTracks().forEach(t => { try { t.stop(); } catch (e) { } });
  }

  async function countCameras() {
    try {
      const devs = await navigator.mediaDevices.enumerateDevices();
      return devs.filter(d => d.kind === 'videoinput').length;
    } catch (e) { return 1; }
  }

  function pickMime() {
    if (typeof MediaRecorder === 'undefined' || !MediaRecorder.isTypeSupported) return '';
    const list = [
      'video/mp4;codecs=avc1.42E01E,mp4a.40.2',
      'video/mp4',
      'video/webm;codecs=vp9,opus',
      'video/webm;codecs=vp8,opus',
      'video/webm'
    ];
    for (const m of list) { try { if (MediaRecorder.isTypeSupported(m)) return m; } catch (e) { } }
    return '';
  }

  const AselyCamera = {
    supported() {
      return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia && window.isSecureContext);
    },
    secureContext() { return !!window.isSecureContext; },
    recorderSupported() { return typeof MediaRecorder !== 'undefined' && !!pickMime(); },
    canPause() { return typeof MediaRecorder !== 'undefined' && typeof MediaRecorder.prototype.pause === 'function'; },
    recordingMime() { return pickMime(); },

    async start(videoId, wantFacing) {
      videoEl = document.getElementById(videoId);
      if (!videoEl) return { ok: false, error: 'unknown' };
      if (!this.supported()) return { ok: false, error: 'unsupported' };
      // switching cameras while recording would cut the recording short
      if (rec && rec.state !== 'inactive') return { ok: false, error: 'recording' };

      stopStream(camStream);
      camStream = null;
      let usedFallback = false;
      try {
        try {
          camStream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: { ideal: wantFacing }, width: { ideal: 1280 }, height: { ideal: 720 } },
            audio: false
          });
        } catch (e) {
          if (mapError(e) === 'constraint') {
            camStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
            usedFallback = true;
          } else throw e;
        }
      } catch (e) {
        return { ok: false, error: mapError(e), message: (e && e.message) || '' };
      }

      const track = camStream.getVideoTracks()[0];
      const settings = track.getSettings ? track.getSettings() : {};
      facing = settings.facingMode || wantFacing;
      videoEl.srcObject = camStream;
      videoEl.muted = true;
      videoEl.playsInline = true;
      try { await videoEl.play(); } catch (e) { }
      // wait for real frames so captures are never blank
      if (videoEl.readyState < 2) {
        await new Promise(res => {
          const done = () => { videoEl.removeEventListener('loadeddata', done); res(); };
          videoEl.addEventListener('loadeddata', done);
          setTimeout(done, 2500);
        });
      }
      track.addEventListener('ended', () => { /* camera unplugged */ });
      return {
        ok: true,
        cameras: await countCameras(),
        facing: usedFallback ? 'user' : facing,
        width: videoEl.videoWidth || settings.width || 0,
        height: videoEl.videoHeight || settings.height || 0
      };
    },

    isOn() { return !!(camStream && camStream.getVideoTracks().some(t => t.readyState === 'live')); },

    /* Stops camera AND microphone tracks and any recording in progress. */
    stop() {
      if (rec && rec.state !== 'inactive') { try { rec.stop(); } catch (e) { } }
      stopStream(camStream);
      stopStream(micStream);
      camStream = null;
      micStream = null;
      if (videoEl) { try { videoEl.pause(); } catch (e) { } videoEl.srcObject = null; }
      return true;
    },

    async enableMic() {
      if (!this.supported()) return { ok: false, error: 'unsupported' };
      if (micStream && micStream.getAudioTracks().some(t => t.readyState === 'live')) return { ok: true };
      try {
        micStream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true }, video: false });
        return { ok: true };
      } catch (e) {
        micStream = null;
        return { ok: false, error: mapError(e) };
      }
    },
    disableMic() { stopStream(micStream); micStream = null; return true; },
    hasMic() { return !!(micStream && micStream.getAudioTracks().some(t => t.readyState === 'live')); },

    /* Draws the current frame to a canvas and stores it as a JPEG photo. */
    async capture(sessionId, mirror, replaceId) {
      if (!videoEl || !this.isOn() || !videoEl.videoWidth) throw new Error('camera_off');
      const w = videoEl.videoWidth, h = videoEl.videoHeight;
      const c = document.createElement('canvas');
      c.width = w; c.height = h;
      const ctx = c.getContext('2d');
      if (mirror) { ctx.translate(w, 0); ctx.scale(-1, 1); }
      ctx.drawImage(videoEl, 0, 0, w, h);
      const blob = await new Promise((res, rej) => c.toBlob(b => b ? res(b) : rej(new Error('capture_failed')), 'image/jpeg', 0.93));
      let created = null;
      if (replaceId && AselyStore.has(replaceId)) {
        const old = (await AselyStore.list()).find(m => m.id === replaceId);
        created = old ? old.created : null;
        await AselyStore.remove(replaceId);
      }
      const now = new Date();
      const meta = { sessionId, kind: 'photo', origin: 'camera', name: `asely-photo-${AselyUtil.stamp(null, 'file')}-${Math.floor(Math.random() * 90 + 10)}` };
      if (created) meta.created = created;
      else meta.created = now.toISOString();
      return AselyStore.put(meta, blob);
    },

    /* ---------- recording ---------- */
    async startRecording(withAudio) {
      if (!this.isOn()) return { ok: false, error: 'camera_off' };
      const mime = pickMime();
      if (typeof MediaRecorder === 'undefined' || !mime) return { ok: false, error: 'unsupported' };
      if (rec && rec.state !== 'inactive') return { ok: false, error: 'recording' };

      const tracks = [...camStream.getVideoTracks()];
      let audioIncluded = false;
      if (withAudio && this.hasMic()) { tracks.push(...micStream.getAudioTracks()); audioIncluded = true; }

      try {
        rec = new MediaRecorder(new MediaStream(tracks), { mimeType: mime, videoBitsPerSecond: 4000000 });
      } catch (e) {
        try { rec = new MediaRecorder(new MediaStream(tracks)); } catch (e2) { return { ok: false, error: 'failed' }; }
      }
      chunks = [];
      recError = null;
      recMeta = null;
      recMime = rec.mimeType || mime;
      rec.ondataavailable = ev => { if (ev.data && ev.data.size > 0) chunks.push(ev.data); };
      rec.onerror = ev => { recError = (ev && ev.error && ev.error.name) || 'failed'; };
      try { rec.start(1000); } catch (e) { return { ok: false, error: 'failed' }; }
      recStarted = performance.now();
      pausedAt = 0;
      pausedTotal = 0;
      return { ok: true, mime: recMime, audio: audioIncluded };
    },

    pause() {
      if (rec && rec.state === 'recording' && this.canPause()) {
        rec.pause(); pausedAt = performance.now(); return true;
      }
      return false;
    },
    resume() {
      if (rec && rec.state === 'paused') {
        rec.resume(); pausedTotal += performance.now() - pausedAt; pausedAt = 0; return true;
      }
      return false;
    },
    isRecording() { return !!(rec && rec.state !== 'inactive'); },
    isPaused() { return !!(rec && rec.state === 'paused'); },
    recordingFailed() { return recError; },

    elapsed() {
      if (!rec || rec.state === 'inactive') return 0;
      const now = rec.state === 'paused' ? pausedAt : performance.now();
      return Math.max(0, (now - recStarted - pausedTotal) / 1000);
    },

    /* Stops the recorder and stores the finished video. kind/origin describe where it came from. */
    async stopRecording(sessionId, origin, name) {
      if (!rec) return null;
      const r = rec;
      const duration = this.elapsed();
      if (r.state === 'paused') { try { r.resume(); } catch (e) { } }
      const stopped = new Promise(res => { r.onstop = () => res(); });
      if (r.state !== 'inactive') { try { r.stop(); } catch (e) { } } else { return null; }
      await stopped;
      rec = null;
      if (recError) { chunks = []; throw new Error('record_failed'); }
      if (chunks.length === 0) throw new Error('record_failed');
      const blob = new Blob(chunks, { type: recMime.split(';')[0] || 'video/webm' });
      chunks = [];
      const meta = await AselyStore.put({
        sessionId, kind: 'video', origin: origin || 'clip', duration,
        name: name || `asely-${origin === 'session' ? 'session' : 'video'}-${AselyUtil.stamp(null, 'file')}`
      }, blob);
      return meta;
    },

    /* Throw away an unfinished recording without saving anything. */
    discardRecording() {
      if (rec) {
        rec.ondataavailable = null; rec.onstop = null;
        if (rec.state !== 'inactive') { try { rec.stop(); } catch (e) { } }
      }
      rec = null; chunks = [];
      return true;
    }
  };

  window.AselyCamera = AselyCamera;
})();
